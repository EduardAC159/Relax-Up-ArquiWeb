package pe.edu.upc.relaxup.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.relaxup.Dtos.MetaEmocionalDTO;
import pe.edu.upc.relaxup.Dtos.QuantityMetaEmocionalDTO;
import pe.edu.upc.relaxup.Entities.MetaEmocional;
import pe.edu.upc.relaxup.Entities.Usuario;
import pe.edu.upc.relaxup.ServiceInterfaces.IMetaEmocionalService;
import pe.edu.upc.relaxup.ServiceInterfaces.IUsuarioService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/MetaEmocional")
public class MetaEmocionalController {

    @Autowired
    private IMetaEmocionalService meS;
    @Autowired
    private IUsuarioService uS;

    @GetMapping("/listar")
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    public ResponseEntity<?> Listar(){
        ModelMapper m = new ModelMapper();
        List<MetaEmocionalDTO> listarMeta = meS.list().stream()
                .map(x->m.map(x,MetaEmocionalDTO.class)).collect(Collectors.toList());
        return ResponseEntity.ok(listarMeta);
    }

    @GetMapping("/CantidadMetaEmocionalUsuario")
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    public ResponseEntity<?> CantidadMetaEmocionalUsuario() {
        List<Object[]> listaCantidad = meS.CantidadMetaEmocionalUsuario();
        if (listaCantidad.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No hay competencias");
        }
        List<QuantityMetaEmocionalDTO> respuesta = new ArrayList<>();
        for (Object[] fila : listaCantidad) {
            QuantityMetaEmocionalDTO dto = new QuantityMetaEmocionalDTO();
            dto.setCantidad_Meta_Emocional_Usuario(((Number) fila[0]).intValue());
            respuesta.add(dto);

        }
        return ResponseEntity.ok(respuesta);
    }
    @GetMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    public ResponseEntity<?> buscarPorId(@PathVariable int id) {
        ModelMapper m = new ModelMapper();
        Optional<MetaEmocional> meta = meS.listId(id);

        if (meta.isPresent()) {
            MetaEmocionalDTO dto = m.map(meta.get(), MetaEmocionalDTO.class);
            return ResponseEntity.ok(dto);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Meta emocional no encontrada");
        }
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    public ResponseEntity<String> eliminar(@PathVariable int id) {
        Optional<MetaEmocional> meta = meS.listId(id);

        if (meta.isPresent()) {
            meS.delete(id);
            return ResponseEntity.ok("Meta emocional eliminada correctamente");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Meta emocional no encontrada");
        }
    }

    @PostMapping("/nuevo")
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    public ResponseEntity<?> registrar(@RequestBody MetaEmocionalDTO dto){
        ModelMapper m = new ModelMapper();
        Optional<Usuario> user = uS.listId(dto.getIdUsuario());
        if (user.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("El curso no existe");
        }
        MetaEmocional me = m.map(dto, MetaEmocional.class);
        me.setUsuario(user.get());

        MetaEmocional meta = meS.insert(me);
        MetaEmocionalDTO responseDTO = m.map(meta, MetaEmocionalDTO.class);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(responseDTO);
    }

    @PutMapping("/actualiza")
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    public ResponseEntity<String> actualizar(@RequestBody MetaEmocionalDTO dto) {

        Optional<MetaEmocional> existente = meS.listId(dto.getIdMeta());
        if (existente.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Meta emocional no encontrado");
        }

        MetaEmocional met = existente.get();

        met.setDescripcion(dto.getDescripcion());
        met.setFechaInicio(dto.getFechaInicio());
        met.setFechaFin(dto.getFechaFin());
        met.setEstado(dto.getEstado());
        meS.update(met);

        return ResponseEntity.ok("Mrta emocional actualizado correctamente");
    }
}
