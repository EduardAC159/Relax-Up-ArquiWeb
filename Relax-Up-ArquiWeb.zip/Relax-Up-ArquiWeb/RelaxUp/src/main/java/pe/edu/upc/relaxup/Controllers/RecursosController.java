package pe.edu.upc.relaxup.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.relaxup.Dtos.RecursosDTO;
import pe.edu.upc.relaxup.Entities.Recursos;
import pe.edu.upc.relaxup.Entities.Usuario;
import pe.edu.upc.relaxup.ServiceInterfaces.IRecursosService;
import pe.edu.upc.relaxup.ServiceInterfaces.IUsuarioService;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/Recursos")
public class RecursosController {

    @Autowired
    private IRecursosService recS;
    @Autowired
    private IUsuarioService uS;

    @GetMapping
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    public ResponseEntity<?> Listar(){
        ModelMapper m = new ModelMapper();
        List<RecursosDTO> ListarRecursos = recS.list().stream()
                .map(x->m.map(x,RecursosDTO.class)).collect(Collectors.toList());

        if (ListarRecursos.isEmpty())
        {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No hay recursos registrados");
        }
        return ResponseEntity.ok(ListarRecursos);
    }

    @PostMapping("/nuevo")
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    public ResponseEntity<?> registrar(@RequestBody RecursosDTO dto){
        ModelMapper m = new ModelMapper();
        Optional<Usuario> user = uS.listId(dto.getIdUsuario());
        if (user.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("El curso no existe");
        }
        Recursos recursos = m.map(dto, Recursos.class);
        recursos.setUsuario(user.get());

        Recursos rec = recS.insert(recursos);
        RecursosDTO responseDTO = m.map(rec, RecursosDTO.class);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(responseDTO);
    }

    @PutMapping("/actualiza")
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    public ResponseEntity<String> actualizar(@RequestBody RecursosDTO dto) {

        Optional<Recursos> existente = recS.listId(dto.getIdRecursos());
        if (existente.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Recursos  no encontrado");
        }

        Recursos rec = existente.get();

        rec.setTitulo(dto.getTitulo());
        rec.setTipo(dto.getTipo());
        rec.setEnlace(dto.getEnlace());

        recS.update(rec);

        return ResponseEntity.ok("Recursos actualizado correctamente");
    }
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    public ResponseEntity<String> eliminar(@PathVariable int id) {
        Optional<Recursos> rec = recS.listId(id);

        if (rec.isPresent()) {
            recS.delete(id);
            return ResponseEntity.ok("Recursos eliminado correctamente");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("machine no encontrado");
        }
    }
}
