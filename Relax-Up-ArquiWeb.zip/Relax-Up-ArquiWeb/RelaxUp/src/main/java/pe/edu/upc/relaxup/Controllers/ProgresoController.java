package pe.edu.upc.relaxup.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.relaxup.Dtos.ProgresoDTO;
import pe.edu.upc.relaxup.Entities.Progreso;
import pe.edu.upc.relaxup.ServiceInterfaces.IProgresoService;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/Progreso")
public class ProgresoController {
    @Autowired
    private IProgresoService pS;

    @GetMapping
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    public ResponseEntity<List<ProgresoDTO>> Listar(){
        ModelMapper m = new ModelMapper();
        List<ProgresoDTO> ListarProgreso = pS.list().stream()
                .map(x->m.map(x,ProgresoDTO.class)).collect(Collectors.toList());
        return ResponseEntity.ok(ListarProgreso);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    public ResponseEntity<?> buscarPorId(@PathVariable int id) {
        ModelMapper m = new ModelMapper();
        Optional<Progreso> progreso = pS.listId(id);

        if (progreso.isPresent()) {
            ProgresoDTO dto = m.map(progreso.get(), ProgresoDTO.class);
            return ResponseEntity.ok(dto);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Progreso no encontrado");
        }
    }

    @PostMapping("/nuevo")
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    public ResponseEntity<?> registrar(@RequestBody ProgresoDTO dto){
        ModelMapper m = new ModelMapper();
        Progreso p = m.map(dto, Progreso.class);

        Progreso pro = pS.insert(p);
        ProgresoDTO progresoDTO = m.map(pro, ProgresoDTO.class);
        return ResponseEntity.status(HttpStatus.CREATED).body(progresoDTO);
    }

    @PutMapping("/actualiza")
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    public ResponseEntity<String> actualizar(@RequestBody ProgresoDTO dto) {

        Optional<Progreso> existente = pS.listId(dto.getIdProgreso());
        if (existente.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Progreso  no encontrado");
        }

        Progreso pro = existente.get();

        pro.setNivelControlIra(dto.getNivelControlIra());
        pro.setFecha(dto.getFecha());
        pro.setObservaciones(dto.getObservaciones());

        pS.update(pro);

        return ResponseEntity.ok("Recodatorio actualizado correctamente");
    }
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    public ResponseEntity<String> eliminar(@PathVariable int id) {
        Optional<Progreso> existente = pS.listId(id);

        if (existente.isPresent()) {
            pS.delete(id);
            return ResponseEntity.ok("Progreso eliminado correctamente");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Progreso no encontrado");
        }
    }
}
