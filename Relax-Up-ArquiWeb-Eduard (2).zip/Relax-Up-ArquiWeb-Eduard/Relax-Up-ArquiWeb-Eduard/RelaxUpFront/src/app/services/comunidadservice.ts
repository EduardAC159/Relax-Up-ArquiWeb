import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { Comunidad } from '../models/Comunidad';

const base_url = environment.base;

@Injectable({
  providedIn: 'root',
})
export class Comunidadservice {
  private url = `${base_url}/api/Comunidad`;
  constructor(private http: HttpClient) {}

  list() {
    return this.http.get<Comunidad[]>(`${this.url}/Listar`);
  }
  insert(c: Comunidad) {
    return this.http.post(`${this.url}/registrar`, c);
  }
  delete(id: number) {
    return this.http.delete(`${this.url}/${id}`, { responseType: 'text' });
  }
}
