package pe.edu.upc.relaxup.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upc.relaxup.Entities.FamiliarUsuario;

import java.util.List;
import java.util.Optional;

public interface IFamiliarUsuarioRepository extends JpaRepository<FamiliarUsuario, Long> {

    List<FamiliarUsuario> findByFamiliar_Id(Long familiarUserId);

    Optional<FamiliarUsuario> findByFamiliar_IdAndUsuario_IdUsuario(Long familiarUserId, int usuarioId);
}