package pe.edu.upc.relaxup.Dtos;

public class PromedioMetaEmocionalDTO {
    private String metaEmocional;
    private double promedio;

    public String getMetaEmocional() {
        return metaEmocional;
    }

    public void setMetaEmocional(String metaEmocional) {
        this.metaEmocional = metaEmocional;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }
}