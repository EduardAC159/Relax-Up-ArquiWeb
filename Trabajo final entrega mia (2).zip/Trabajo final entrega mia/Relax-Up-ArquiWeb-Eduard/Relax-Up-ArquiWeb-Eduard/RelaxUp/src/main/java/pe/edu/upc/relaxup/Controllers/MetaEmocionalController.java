package pe.edu.upc.relaxup.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.relaxup.Dtos.MetaEmocionalDTO;
import pe.edu.upc.relaxup.Dtos.QuantityMetaEmocionalDTO;
import pe.edu.upc.relaxup.Entities.MetaEmocional;
import pe.edu.upc.relaxup.Entities.Usuario;
import pe.edu.upc.relaxup.ServiceInterfaces.IMetaEmocionalService;
import pe.edu.upc.relaxup.ServiceInterfaces.IUsuarioService;
import org.springframework.security.core.Authentication;
import pe.edu.upc.relaxup.Entities.Users;
import pe.edu.upc.relaxup.Repositories.IUsuarioRepository;
import pe.edu.upc.relaxup.Repositories.IUserRepository;
import pe.edu.upc.relaxup.Repositories.IFamiliarUsuarioRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/MetaEmocional")
public class MetaEmocionalController {

    @Autowired
    private IMetaEmocionalService meS;
    @Autowired
    private IUsuarioService uS;
    @Autowired
    private IUsuarioRepository uR;
    @Autowired
    private IUserRepository userR;
    @Autowired
    private IFamiliarUsuarioRepository fuR;

    @GetMapping
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<?> Listar(){
        ModelMapper m = new ModelMapper();
        List<MetaEmocionalDTO> listarMeta = meS.list().stream()
                .map(x->m.map(x,MetaEmocionalDTO.class)).collect(Collectors.toList());
        return ResponseEntity.ok(listarMeta);
    }

    @GetMapping("/CantidadMetaEmocionalUsuario")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<?> CantidadMetaEmocionalUsuario() {
        List<Object[]> listaCantidad = meS.CantidadMetaEmocionalUsuario();
        if (listaCantidad.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No hay competencias");
        }
        List<QuantityMetaEmocionalDTO> respuesta = new ArrayList<>();
        for (Object[] fila : listaCantidad) {
            QuantityMetaEmocionalDTO dto = new QuantityMetaEmocionalDTO();
            dto.setCantidad_Meta_Emocional_Usuario(((Number) fila[0]).intValue());
            respuesta.add(dto);

        }
        return ResponseEntity.ok(respuesta);
    }

    @PostMapping("/nuevo")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<?> registrar(@RequestBody MetaEmocionalDTO dto){
        ModelMapper m = new ModelMapper();
        Optional<Usuario> user = uS.listId(dto.getIdUsuario());
        if (user.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("El curso no existe");
        }
        MetaEmocional me = m.map(dto, MetaEmocional.class);
        me.setUsuario(user.get());

        MetaEmocional meta = meS.insert(me);
        MetaEmocionalDTO responseDTO = m.map(meta, MetaEmocionalDTO.class);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(responseDTO);
    }

    @PutMapping("/actualiza")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<String> actualizar(@RequestBody MetaEmocionalDTO dto) {

        Optional<MetaEmocional> existente = meS.listId(dto.getIdMeta());
        if (existente.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Meta emocional no encontrado");
        }

        MetaEmocional met = existente.get();

        met.setDescripcion(dto.getDescripcion());
        met.setFechaInicio(dto.getFechaInicio());
        met.setFechaFin(dto.getFechaFin());
        met.setEstado(dto.getEstado());
        meS.update(met);

        return ResponseEntity.ok("Mrta emocional actualizado correctamente");
    }
    @GetMapping("/mias")
    @PreAuthorize("hasAuthority('USUARIO')")
    public ResponseEntity<?> misMetas(Authentication auth) {
        Usuario usuario = uR.findByUser_Username(auth.getName())
                .orElseThrow(() -> new RuntimeException("Perfil de usuario no encontrado"));

        ModelMapper m = new ModelMapper();
        List<MetaEmocionalDTO> lista = meS.list().stream()
                .filter(me -> me.getUsuario() != null && me.getUsuario().getIdUsuario() == usuario.getIdUsuario())
                .map(x -> m.map(x, MetaEmocionalDTO.class))
                .collect(Collectors.toList());
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/deMiFamiliar/{usuarioId}")
    @PreAuthorize("hasAuthority('FAMILIAR')")
    public ResponseEntity<?> metasDeFamiliar(@PathVariable int usuarioId, Authentication auth) {
        Users familiar = userR.findOneByUsername(auth.getName());

        boolean vinculado = fuR.findByFamiliar_IdAndUsuario_IdUsuario(familiar.getId(), usuarioId).isPresent();
        if (!vinculado) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No tienes vinculo con este usuario");
        }

        ModelMapper m = new ModelMapper();
        List<MetaEmocionalDTO> lista = meS.list().stream()
                .filter(me -> me.getUsuario() != null && me.getUsuario().getIdUsuario() == usuarioId)
                .map(x -> m.map(x, MetaEmocionalDTO.class))
                .collect(Collectors.toList());
        return ResponseEntity.ok(lista);
    }

    @PostMapping("/mia")
    @PreAuthorize("hasAuthority('USUARIO')")
    public ResponseEntity<?> registrarMiMeta(@RequestBody MetaEmocionalDTO dto, Authentication auth) {
        Usuario usuario = uR.findByUser_Username(auth.getName())
                .orElseThrow(() -> new RuntimeException("Perfil de usuario no encontrado"));

        MetaEmocional me = new MetaEmocional();
        me.setUsuario(usuario);
        me.setDescripcion(dto.getDescripcion());
        me.setFechaInicio(dto.getFechaInicio());
        me.setFechaFin(dto.getFechaFin());
        me.setEstado(dto.getEstado());

        MetaEmocional guardada = meS.insert(me);
        ModelMapper m = new ModelMapper();
        return ResponseEntity.status(HttpStatus.CREATED).body(m.map(guardada, MetaEmocionalDTO.class));
    }
}
