package pe.edu.upc.relaxup.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.relaxup.Dtos.UsuarioDTO;
import pe.edu.upc.relaxup.Entities.FamiliarUsuario;
import pe.edu.upc.relaxup.Entities.Users;
import pe.edu.upc.relaxup.Repositories.IFamiliarUsuarioRepository;
import pe.edu.upc.relaxup.Repositories.IUserRepository;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/FamiliarUsuario")
public class FamiliarUsuarioController {

    @Autowired
    private IFamiliarUsuarioRepository fuR;
    @Autowired
    private IUserRepository userR;

    @GetMapping("/mis-vinculados")
    @PreAuthorize("hasAuthority('FAMILIAR')")
    public ResponseEntity<List<UsuarioDTO>> misVinculados(Authentication auth) {
        Users familiar = userR.findOneByUsername(auth.getName());
        ModelMapper m = new ModelMapper();

        List<UsuarioDTO> vinculados = fuR.findByFamiliar_Id(familiar.getId()).stream()
                .map(FamiliarUsuario::getUsuario)
                .map(u -> m.map(u, UsuarioDTO.class))
                .collect(Collectors.toList());

        return ResponseEntity.ok(vinculados);
    }
}