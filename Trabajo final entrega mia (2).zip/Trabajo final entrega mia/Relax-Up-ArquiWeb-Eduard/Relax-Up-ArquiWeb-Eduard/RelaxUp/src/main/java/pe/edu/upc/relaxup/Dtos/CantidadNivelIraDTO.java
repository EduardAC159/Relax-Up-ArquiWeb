package pe.edu.upc.relaxup.Dtos;

public class CantidadNivelIraDTO {
    private int nivelControlIra;
    private long cantidad;

    public int getNivelControlIra() {
        return nivelControlIra;
    }

    public void setNivelControlIra(int nivelControlIra) {
        this.nivelControlIra = nivelControlIra;
    }

    public long getCantidad() {
        return cantidad;
    }

    public void setCantidad(long cantidad) {
        this.cantidad = cantidad;
    }
}