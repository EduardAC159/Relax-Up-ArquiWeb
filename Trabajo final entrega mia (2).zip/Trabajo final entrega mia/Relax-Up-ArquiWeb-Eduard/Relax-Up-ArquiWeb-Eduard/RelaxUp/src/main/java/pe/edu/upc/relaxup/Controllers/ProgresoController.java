package pe.edu.upc.relaxup.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.relaxup.Dtos.ProgresoDTO;
import pe.edu.upc.relaxup.Entities.Progreso;
import pe.edu.upc.relaxup.Entities.Users;
import pe.edu.upc.relaxup.Repositories.IFamiliarUsuarioRepository;
import pe.edu.upc.relaxup.Repositories.IUserRepository;
import pe.edu.upc.relaxup.Repositories.IUsuarioRepository;
import pe.edu.upc.relaxup.ServiceInterfaces.IProgresoService;
import pe.edu.upc.relaxup.Entities.Usuario;
import pe.edu.upc.relaxup.Dtos.CantidadNivelIraDTO;
import pe.edu.upc.relaxup.Dtos.PromedioMetaEmocionalDTO;
import java.util.ArrayList;
import pe.edu.upc.relaxup.ServiceInterfaces.IMetaEmocionalService;
import pe.edu.upc.relaxup.Entities.MetaEmocional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/Progreso")
public class ProgresoController {
    @Autowired
    private IProgresoService pS;
    @Autowired
    private IUsuarioRepository uR;
    @Autowired
    private IUserRepository userR;
    @Autowired
    private IFamiliarUsuarioRepository fuR;
    @Autowired
    private IMetaEmocionalService meS;

    @GetMapping
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<ProgresoDTO>> Listar(){
        ModelMapper m = new ModelMapper();
        List<ProgresoDTO> ListarProgreso = pS.list().stream()
                .map(x->m.map(x,ProgresoDTO.class)).collect(Collectors.toList());
        return ResponseEntity.ok(ListarProgreso);
    }

    @PostMapping("/nuevo")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<?> registrar(@RequestBody ProgresoDTO dto){
        ModelMapper m = new ModelMapper();
        Progreso p = m.map(dto, Progreso.class);

        Progreso pro = pS.insert(p);
        ProgresoDTO progresoDTO = m.map(pro, ProgresoDTO.class);
        return ResponseEntity.status(HttpStatus.CREATED).body(progresoDTO);
    }

    @PutMapping("/actualiza")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<String> actualizar(@RequestBody ProgresoDTO dto) {

        Optional<Progreso> existente = pS.listId(dto.getIdProgreso());
        if (existente.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Progreso  no encontrado");
        }

        Progreso pro = existente.get();

        pro.setNivelControlIra(dto.getNivelControlIra());
        pro.setFecha(dto.getFecha());
        pro.setObservaciones(dto.getObservaciones());

        pS.update(pro);

        return ResponseEntity.ok("Recodatorio actualizado correctamente");
    }

    @GetMapping("/CantidadPorNivelControlIra")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<CantidadNivelIraDTO>> cantidadPorNivelControlIra() {
        List<Object[]> filas = pS.cantidadPorNivelControlIra();
        List<CantidadNivelIraDTO> respuesta = new ArrayList<>();
        for (Object[] fila : filas) {
            CantidadNivelIraDTO dto = new CantidadNivelIraDTO();
            dto.setNivelControlIra(((Number) fila[0]).intValue());
            dto.setCantidad(((Number) fila[1]).longValue());
            respuesta.add(dto);
        }
        return ResponseEntity.ok(respuesta);
    }

    @GetMapping("/PromedioPorMetaEmocional")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<PromedioMetaEmocionalDTO>> promedioPorMetaEmocional() {
        List<Object[]> filas = pS.promedioPorMetaEmocional();
        List<PromedioMetaEmocionalDTO> respuesta = new ArrayList<>();
        for (Object[] fila : filas) {
            PromedioMetaEmocionalDTO dto = new PromedioMetaEmocionalDTO();
            dto.setMetaEmocional((String) fila[0]);
            dto.setPromedio(((Number) fila[1]).doubleValue());
            respuesta.add(dto);
        }
        return ResponseEntity.ok(respuesta);
    }

    @GetMapping("/mias-nivel-control-ira")
    @PreAuthorize("hasAuthority('USUARIO')")
    public ResponseEntity<List<CantidadNivelIraDTO>> misNivelesControlIra(Authentication auth) {
        Usuario usuario = uR.findByUser_Username(auth.getName())
                .orElseThrow(() -> new RuntimeException("Perfil de usuario no encontrado"));

        List<Object[]> filas = pS.cantidadPorNivelControlIraDeUsuario(usuario.getIdUsuario());
        List<CantidadNivelIraDTO> respuesta = new ArrayList<>();
        for (Object[] fila : filas) {
            CantidadNivelIraDTO dto = new CantidadNivelIraDTO();
            dto.setNivelControlIra(((Number) fila[0]).intValue());
            dto.setCantidad(((Number) fila[1]).longValue());
            respuesta.add(dto);
        }
        return ResponseEntity.ok(respuesta);
    }

    @GetMapping("/mi-promedio-meta")
    @PreAuthorize("hasAuthority('USUARIO')")
    public ResponseEntity<List<PromedioMetaEmocionalDTO>> miPromedioMeta(Authentication auth) {
        Usuario usuario = uR.findByUser_Username(auth.getName())
                .orElseThrow(() -> new RuntimeException("Perfil de usuario no encontrado"));

        List<Object[]> filas = pS.promedioPorMetaEmocionalDeUsuario(usuario.getIdUsuario());
        List<PromedioMetaEmocionalDTO> respuesta = new ArrayList<>();
        for (Object[] fila : filas) {
            PromedioMetaEmocionalDTO dto = new PromedioMetaEmocionalDTO();
            dto.setMetaEmocional((String) fila[0]);
            dto.setPromedio(((Number) fila[1]).doubleValue());
            respuesta.add(dto);
        }
        return ResponseEntity.ok(respuesta);
    }

    @GetMapping("/deMiFamiliar-nivel-control-ira/{usuarioId}")
    @PreAuthorize("hasAuthority('FAMILIAR')")
    public ResponseEntity<?> nivelesControlIraDeFamiliar(@PathVariable int usuarioId, Authentication auth) {
        Users familiar = userR.findOneByUsername(auth.getName());
        boolean vinculado = fuR.findByFamiliar_IdAndUsuario_IdUsuario(familiar.getId(), usuarioId).isPresent();
        if (!vinculado) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No tienes vinculo con este usuario");
        }

        List<Object[]> filas = pS.cantidadPorNivelControlIraDeUsuario(usuarioId);
        List<CantidadNivelIraDTO> respuesta = new ArrayList<>();
        for (Object[] fila : filas) {
            CantidadNivelIraDTO dto = new CantidadNivelIraDTO();
            dto.setNivelControlIra(((Number) fila[0]).intValue());
            dto.setCantidad(((Number) fila[1]).longValue());
            respuesta.add(dto);
        }
        return ResponseEntity.ok(respuesta);
    }

    @GetMapping("/deMiFamiliar-promedio-meta/{usuarioId}")
    @PreAuthorize("hasAuthority('FAMILIAR')")
    public ResponseEntity<?> promedioMetaDeFamiliar(@PathVariable int usuarioId, Authentication auth) {
        Users familiar = userR.findOneByUsername(auth.getName());
        boolean vinculado = fuR.findByFamiliar_IdAndUsuario_IdUsuario(familiar.getId(), usuarioId).isPresent();
        if (!vinculado) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No tienes vinculo con este usuario");
        }

        List<Object[]> filas = pS.promedioPorMetaEmocionalDeUsuario(usuarioId);
        List<PromedioMetaEmocionalDTO> respuesta = new ArrayList<>();
        for (Object[] fila : filas) {
            PromedioMetaEmocionalDTO dto = new PromedioMetaEmocionalDTO();
            dto.setMetaEmocional((String) fila[0]);
            dto.setPromedio(((Number) fila[1]).doubleValue());
            respuesta.add(dto);
        }
        return ResponseEntity.ok(respuesta);
    }

    @GetMapping("/mias")
    @PreAuthorize("hasAuthority('USUARIO')")
    public ResponseEntity<?> misProgresos(Authentication auth) {
        Usuario usuario = uR.findByUser_Username(auth.getName())
                .orElseThrow(() -> new RuntimeException("Perfil de usuario no encontrado"));

        ModelMapper m = new ModelMapper();
        List<ProgresoDTO> lista = pS.list().stream()
                .filter(p -> p.getMetaEmocional() != null
                        && p.getMetaEmocional().getUsuario() != null
                        && p.getMetaEmocional().getUsuario().getIdUsuario() == usuario.getIdUsuario())
                .map(x -> m.map(x, ProgresoDTO.class))
                .collect(Collectors.toList());
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/deMiFamiliar/{usuarioId}")
    @PreAuthorize("hasAuthority('FAMILIAR')")
    public ResponseEntity<?> progresosDeFamiliar(@PathVariable int usuarioId, Authentication auth) {
        Users familiar = userR.findOneByUsername(auth.getName());

        boolean vinculado = fuR.findByFamiliar_IdAndUsuario_IdUsuario(familiar.getId(), usuarioId).isPresent();
        if (!vinculado) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No tienes vinculo con este usuario");
        }

        ModelMapper m = new ModelMapper();
        List<ProgresoDTO> lista = pS.list().stream()
                .filter(p -> p.getMetaEmocional() != null
                        && p.getMetaEmocional().getUsuario() != null
                        && p.getMetaEmocional().getUsuario().getIdUsuario() == usuarioId)
                .map(x -> m.map(x, ProgresoDTO.class))
                .collect(Collectors.toList());
        return ResponseEntity.ok(lista);
    }

    // USUARIO registra su propio progreso, ligado a una de SUS metas emocionales
    @PostMapping("/mia")
    @PreAuthorize("hasAuthority('USUARIO')")
    public ResponseEntity<?> registrarMiProgreso(@RequestBody ProgresoDTO dto, Authentication auth) {
        Usuario usuario = uR.findByUser_Username(auth.getName())
                .orElseThrow(() -> new RuntimeException("Perfil de usuario no encontrado"));

        Optional<MetaEmocional> metaOpt = meS.listId(dto.getIdMetaEmocional());
        if (metaOpt.isEmpty() || metaOpt.get().getUsuario() == null
                || metaOpt.get().getUsuario().getIdUsuario() != usuario.getIdUsuario()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Esa meta no te pertenece");
        }

        Progreso p = new Progreso();
        p.setMetaEmocional(metaOpt.get());
        p.setNivelControlIra(dto.getNivelControlIra());
        p.setFecha(dto.getFecha());
        p.setObservaciones(dto.getObservaciones());

        Progreso guardado = pS.insert(p);
        ModelMapper m = new ModelMapper();
        return ResponseEntity.status(HttpStatus.CREATED).body(m.map(guardado, ProgresoDTO.class));
    }

    // FAMILIAR registra progreso a nombre del usuario vinculado
    @PostMapping("/registrar-para/{usuarioId}")
    @PreAuthorize("hasAuthority('FAMILIAR')")
    public ResponseEntity<?> registrarProgresoParaUsuario(
            @PathVariable int usuarioId, @RequestBody ProgresoDTO dto, Authentication auth) {
        Users familiar = userR.findOneByUsername(auth.getName());

        boolean vinculado = fuR.findByFamiliar_IdAndUsuario_IdUsuario(familiar.getId(), usuarioId).isPresent();
        if (!vinculado) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No tienes vinculo con este usuario");
        }

        Optional<MetaEmocional> metaOpt = meS.listId(dto.getIdMetaEmocional());
        if (metaOpt.isEmpty() || metaOpt.get().getUsuario() == null
                || metaOpt.get().getUsuario().getIdUsuario() != usuarioId) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Esa meta no pertenece a ese usuario");
        }

        Progreso p = new Progreso();
        p.setMetaEmocional(metaOpt.get());
        p.setNivelControlIra(dto.getNivelControlIra());
        p.setFecha(dto.getFecha());
        p.setObservaciones(dto.getObservaciones());

        Progreso guardado = pS.insert(p);
        ModelMapper m = new ModelMapper();
        return ResponseEntity.status(HttpStatus.CREATED).body(m.map(guardado, ProgresoDTO.class));
    }
}