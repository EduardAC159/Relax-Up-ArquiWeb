package pe.edu.upc.relaxup.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.relaxup.Dtos.EmergenciaDTO;
import pe.edu.upc.relaxup.Entities.Emergencia;
import pe.edu.upc.relaxup.ServiceInterfaces.IEmergenciaServicio;
import org.springframework.security.core.Authentication;
import pe.edu.upc.relaxup.Entities.Usuario;
import pe.edu.upc.relaxup.Entities.Users;
import pe.edu.upc.relaxup.Repositories.IUsuarioRepository;
import pe.edu.upc.relaxup.Repositories.IUserRepository;
import pe.edu.upc.relaxup.Repositories.IFamiliarUsuarioRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/Emergencias")
public class EmergenciaController {
    @Autowired
    private IEmergenciaServicio eS;
    @Autowired
    private IUsuarioRepository uR;
    @Autowired
    private IUserRepository userR;
    @Autowired
    private IFamiliarUsuarioRepository fuR;

    @GetMapping("/listar")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<EmergenciaDTO>> Listar(){
        ModelMapper m = new ModelMapper();
        List<EmergenciaDTO> ListarEmergencia = eS.list().stream()
                .map(x->m.map(x,EmergenciaDTO.class)).collect(Collectors.toList());
        return ResponseEntity.ok(ListarEmergencia);
    }
    @PostMapping("/nuevo")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<?> registrar(@RequestBody EmergenciaDTO dto){
        ModelMapper m = new ModelMapper();
        Emergencia e = m.map(dto, Emergencia.class);

        Emergencia eme = eS.insert(e);
        EmergenciaDTO responseDTO = m.map(eme, EmergenciaDTO.class);
        return ResponseEntity.status(HttpStatus.CREATED).body(responseDTO);
    }

    @PutMapping("/actualiza")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<String> actualizar(@RequestBody EmergenciaDTO dto) {

        Optional<Emergencia> existente = eS.listId(dto.getIdEmergencia());
        if (existente.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Emergencia no encontrado");
        }

        Emergencia eme = existente.get();

        eme.setTipo(dto.getTipo());
        eme.setDescripcion(dto.getDescripcion());
        eme.setFecha(dto.getFecha());

        eS.update(eme);

        return ResponseEntity.ok("interaccion actualizado correctamente");
    }
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<String> eliminar(@PathVariable int id) {
        Optional<Emergencia> emergencia = eS.listId(id);

        if (emergencia.isPresent()) {
            eS.delete(id);
            return ResponseEntity.ok("Emergencia eliminado correctamente");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("machine no encontrado");
        }
    }
    @GetMapping("/mias")
    @PreAuthorize("hasAuthority('USUARIO')")
    public ResponseEntity<List<EmergenciaDTO>> misEmergencias(Authentication auth) {
        Usuario usuario = uR.findByUser_Username(auth.getName())
                .orElseThrow(() -> new RuntimeException("Perfil de usuario no encontrado"));

        ModelMapper m = new ModelMapper();
        List<EmergenciaDTO> lista = eS.list().stream()
                .filter(e -> e.getUsuario() != null && e.getUsuario().getIdUsuario() == usuario.getIdUsuario())
                .map(x -> m.map(x, EmergenciaDTO.class))
                .collect(Collectors.toList());
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/deMiFamiliar/{usuarioId}")
    @PreAuthorize("hasAuthority('FAMILIAR')")
    public ResponseEntity<?> emergenciasDeFamiliar(@PathVariable int usuarioId, Authentication auth) {
        Users familiar = userR.findOneByUsername(auth.getName());

        boolean vinculado = fuR.findByFamiliar_IdAndUsuario_IdUsuario(familiar.getId(), usuarioId).isPresent();
        if (!vinculado) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No tienes vinculo con este usuario");
        }

        ModelMapper m = new ModelMapper();
        List<EmergenciaDTO> lista = eS.list().stream()
                .filter(e -> e.getUsuario() != null && e.getUsuario().getIdUsuario() == usuarioId)
                .map(x -> m.map(x, EmergenciaDTO.class))
                .collect(Collectors.toList());
        return ResponseEntity.ok(lista);
    }

    // FAMILIAR registra una emergencia a nombre del usuario vinculado
    @PostMapping("/registrar-para/{usuarioId}")
    @PreAuthorize("hasAuthority('FAMILIAR')")
    public ResponseEntity<?> registrarEmergenciaParaUsuario(
            @PathVariable int usuarioId, @RequestBody EmergenciaDTO dto, Authentication auth) {
        Users familiar = userR.findOneByUsername(auth.getName());

        boolean vinculado = fuR.findByFamiliar_IdAndUsuario_IdUsuario(familiar.getId(), usuarioId).isPresent();
        if (!vinculado) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No tienes vinculo con este usuario");
        }

        Optional<Usuario> usuarioOpt = uR.findById(usuarioId);
        if (usuarioOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuario no encontrado");
        }

        Emergencia e = new Emergencia();
        e.setUsuario(usuarioOpt.get());
        e.setTipo(dto.getTipo());
        e.setDescripcion(dto.getDescripcion());
        e.setFecha(dto.getFecha());

        Emergencia guardada = eS.insert(e);
        ModelMapper m = new ModelMapper();
        return ResponseEntity.status(HttpStatus.CREATED).body(m.map(guardada, EmergenciaDTO.class));
    }
}
