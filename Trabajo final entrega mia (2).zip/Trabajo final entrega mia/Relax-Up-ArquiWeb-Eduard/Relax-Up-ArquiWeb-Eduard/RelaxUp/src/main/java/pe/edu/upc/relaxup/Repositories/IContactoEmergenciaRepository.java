package pe.edu.upc.relaxup.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import pe.edu.upc.relaxup.Entities.ContactoEmergencia;

import java.util.List;

@Repository
public interface    IContactoEmergenciaRepository extends JpaRepository<ContactoEmergencia,Integer> {

    @Query(value = "SELECT relacion, COUNT(*) AS cantidad " +
            "FROM contacto_emergencia " +
            "GROUP BY relacion " +
            "ORDER BY cantidad DESC", nativeQuery = true)
    List<Object[]> cantidadPorParentesco();
}