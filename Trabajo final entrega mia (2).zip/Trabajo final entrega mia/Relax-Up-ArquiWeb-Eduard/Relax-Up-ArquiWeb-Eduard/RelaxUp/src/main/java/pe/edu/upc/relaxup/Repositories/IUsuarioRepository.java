package pe.edu.upc.relaxup.Repositories;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pe.edu.upc.relaxup.Entities.Usuario;

@Repository
public interface IUsuarioRepository  extends JpaRepository<Usuario,Integer> {
    Optional<Usuario> findByUser_Username(String username);
}
