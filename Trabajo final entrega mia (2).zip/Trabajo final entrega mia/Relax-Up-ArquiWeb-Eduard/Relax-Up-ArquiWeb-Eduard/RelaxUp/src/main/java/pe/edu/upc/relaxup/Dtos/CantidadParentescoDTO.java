package pe.edu.upc.relaxup.Dtos;

public class CantidadParentescoDTO {
    private String relacion;
    private long cantidad;

    public String getRelacion() {
        return relacion;
    }

    public void setRelacion(String relacion) {
        this.relacion = relacion;
    }

    public long getCantidad() {
        return cantidad;
    }

    public void setCantidad(long cantidad) {
        this.cantidad = cantidad;
    }
}