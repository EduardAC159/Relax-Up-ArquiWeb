import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { Progreso } from '../models/progreso';

const base_url = environment.base;

@Injectable({
  providedIn: 'root',
})
export class Progresoservice {
  private url = `${base_url}/api/Progreso`;
  constructor(private http: HttpClient) {}

  // El backend no expone DELETE para Progreso
  list() {
    return this.http.get<Progreso[]>(`${this.url}`);
  }
  insert(p: Progreso) {
    return this.http.post(`${this.url}/nuevo`, p);
  }
}
