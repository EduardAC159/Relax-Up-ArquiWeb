import { Component, ChangeDetectorRef } from '@angular/core';
import { NavigationEnd, Router, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { filter } from 'rxjs';
import { Menucomponent } from './components/menucomponent/menucomponent';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Menucomponent, CommonModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  mostrarMenu = true;

  constructor(
    private router: Router,
    private cdr: ChangeDetectorRef,
  ) {
    this.router.events.pipe(filter((e) => e instanceof NavigationEnd)).subscribe((e) => {
      const url = (e as NavigationEnd).urlAfterRedirects;
      this.mostrarMenu = url !== '/login';
      this.cdr.detectChanges();
    });
  }
}  