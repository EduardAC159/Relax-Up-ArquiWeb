import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { Recordatorio } from '../models/recordatorio';

const base_url = environment.base;

@Injectable({
  providedIn: 'root',
})
export class Recordatorioservice {
  private url = `${base_url}/api/Recordatorio`;
  constructor(private http: HttpClient) {}

  list() {
    return this.http.get<Recordatorio[]>(`${this.url}`);
  }
  insert(r: Recordatorio) {
    return this.http.post(`${this.url}/nuevo`, r);
  }
  delete(id: number) {
    return this.http.delete(`${this.url}/${id}`, { responseType: 'text' });
  }
}
