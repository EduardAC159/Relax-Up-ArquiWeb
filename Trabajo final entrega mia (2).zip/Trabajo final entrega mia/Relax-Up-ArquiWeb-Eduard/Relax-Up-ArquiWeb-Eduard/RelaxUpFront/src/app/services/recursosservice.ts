import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { Recursos } from '../models/recursos';

const base_url = environment.base;

@Injectable({
  providedIn: 'root',
})
export class Recursosservice {
  private url = `${base_url}/api/Recursos`;
  constructor(private http: HttpClient) {}

  list() {
    return this.http.get<Recursos[]>(`${this.url}`);
  }
  insert(r: Recursos) {
    return this.http.post(`${this.url}/nuevo`, r);
  }
  delete(id: number) {
    return this.http.delete(`${this.url}/${id}`, { responseType: 'text' });
  }
}
