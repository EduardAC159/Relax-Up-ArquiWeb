import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Usuario } from '../models/usuario';

const base_url = environment.base;

@Injectable({
  providedIn: 'root',
})
export class Familiarusuarioservice {
  private url = `${base_url}/api/FamiliarUsuario`;
  constructor(private http: HttpClient) {}

  misVinculados(): Observable<Usuario[]> {
    return this.http.get<Usuario[]>(`${this.url}/mis-vinculados`);
  }
}