import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { Comunidad } from '../models/Comunidad';
import { Observable } from 'rxjs';

const base_url = environment.base;

@Injectable({
  providedIn: 'root',
})
export class Comunidadservice {
  private url = `${base_url}/api/Comunidad`;
  constructor(private http: HttpClient) {}

  list() {
    return this.http.get<Comunidad[]>(`${this.url}/listar`);
  }
  insert(c: Comunidad) {
    return this.http.post(`${this.url}/nuevo`, c);
  }
  delete(id: number) {
    return this.http.delete(`${this.url}/${id}`, { responseType: 'text' });
  }
  cantidadRegistradas(): Observable<number> {
    return this.http.get<number>(`${this.url}/CantidadRegistradas`);
  }
}
