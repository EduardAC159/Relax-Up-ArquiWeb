import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { MetaEmocional } from '../models/meta-emocional';

const base_url = environment.base;

@Injectable({
  providedIn: 'root',
})
export class Metaemocionalservice {
  private url = `${base_url}/api/MetaEmocional`;
  constructor(private http: HttpClient) {}

  // El backend no expone DELETE para MetaEmocional
  list() {
    return this.http.get<MetaEmocional[]>(`${this.url}`);
  }
  insert(me: MetaEmocional) {
    return this.http.post(`${this.url}/nuevo`, me);
  }
  mias() {
    return this.http.get<MetaEmocional[]>(`${this.url}/mias`);
  }
  deMiFamiliar(usuarioId: number) {
    return this.http.get<MetaEmocional[]>(`${this.url}/deMiFamiliar/${usuarioId}`);
  }
  registrarMia(me: MetaEmocional) {
    return this.http.post(`${this.url}/mia`, me);
  }
}
