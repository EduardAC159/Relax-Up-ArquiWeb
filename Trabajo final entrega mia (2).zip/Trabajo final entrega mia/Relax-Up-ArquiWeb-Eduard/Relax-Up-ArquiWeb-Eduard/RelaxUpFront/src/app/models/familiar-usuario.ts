import { Usuario } from './usuario';

export type UsuarioVinculado = Usuario;