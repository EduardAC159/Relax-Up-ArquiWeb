export class Recordatorio {
    idRecordatorio: number = 0
    mensaje: string = ''
    fechaHora: string = ''
    tipo: string = ''
    idUsuario: number = 0
}
