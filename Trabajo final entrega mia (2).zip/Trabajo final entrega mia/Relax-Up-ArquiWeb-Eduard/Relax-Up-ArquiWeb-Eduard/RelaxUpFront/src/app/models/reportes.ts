export class CantidadNivelIraDTO {
nivelControlIra: number = 0;
cantidad: number = 0;
}

export class PromedioMetaEmocionalDTO {
metaEmocional: string = '';
promedio: number = 0;
}

export class CantidadParentescoDTO {
relacion: string = '';
cantidad: number = 0;
}