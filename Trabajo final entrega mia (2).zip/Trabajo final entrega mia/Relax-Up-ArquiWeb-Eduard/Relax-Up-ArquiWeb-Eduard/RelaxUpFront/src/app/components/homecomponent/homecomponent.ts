import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

interface Scenario {
  title: string;
  text: string;
}

interface Step {
  title: string;
  body: string;
}

@Component({
  selector: 'app-homecomponent',
  imports: [CommonModule],
  templateUrl: './homecomponent.html',
  styleUrl: './homecomponent.css',
})
export class Homecomponent {
  scenarios: Scenario[] = [
    {
      title: 'El mensaje que casi enviaste',
      text: 'Tenías el pulgar sobre "enviar" y algo te hizo detenerte a tiempo.'
    },
    {
      title: 'La discusión que subió de tono',
      text: 'Notaste tu voz cambiar antes de darte cuenta de lo que estabas diciendo.'
    },
    {
      title: 'La decisión tomada con rabia',
      text: 'Elegiste algo en caliente que, ya frío, no reconociste como tuyo.'
    }
  ];

  steps: Step[] = [
    {
      title: 'Notas la tensión subir',
      body: 'Antes de que la ira tome el control, algo en ti ya lo registra: el pecho apretado, la mandíbula tensa, el pensamiento acelerado.'
    },
    {
      title: 'Hablas con Pausa en el momento',
      body: 'Escribes o hablas con la IA justo cuando lo necesitas, sin pedir cita ni esperar a "calmarte primero".'
    },
    {
      title: 'Encuentras las palabras, no los gritos',
      body: 'Pausa te ayuda a nombrar lo que sientes y por qué, para que puedas expresarlo sin que te controle.'
    },
    {
      title: 'Vuelves a la conversación con calma',
      body: 'Regresas a la persona o la situación con la cabeza más clara, no con más leña sobre el fuego.'
    }
  ];

  trustPoints: string[] = [
    'Nada de lo que escribes se comparte sin tu permiso.',
    'Puedes borrar tu historial cuando quieras.',
    'No necesitas justificar por qué te sientes así.'
  ];

  onStart(): void {
    // Conectar aquí con el flujo real de inicio de conversación
    // (navegación a /chat, apertura de modal, etc.)
    console.log('Iniciar conversación con Pausa');
  }
}
