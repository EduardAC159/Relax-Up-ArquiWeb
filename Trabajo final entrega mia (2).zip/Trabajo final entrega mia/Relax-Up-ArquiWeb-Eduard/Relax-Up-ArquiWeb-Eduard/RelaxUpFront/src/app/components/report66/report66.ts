import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ChartDataset, ChartOptions, ChartType } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';
import { MatIconModule } from '@angular/material/icon';
import { Progresoservice } from '../../services/progresoservice';
import { Authservice } from '../../services/authservice';
import { Familiarusuarioservice } from '../../services/familiarusuarioservice';
import { PromedioMetaEmocionalDTO } from '../../models/reportes';

@Component({
  selector: 'app-report66',
  imports: [BaseChartDirective, MatIconModule],
  templateUrl: './report66.html',
  styleUrl: './report66.css',
})
export class Report66 implements OnInit {
  hasData = false;
  barChartOptions: ChartOptions = {
    responsive: true,
  };
  barChartLegend = true;
  barChartLabels: string[] = [];
  barChartData: ChartDataset[] = [];
  barChartType: ChartType = 'bar';

  constructor(
    private pS: Progresoservice,
    private authS: Authservice,
    private fuS: Familiarusuarioservice,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnInit(): void {
    if (this.authS.esAdmin()) {
      this.pS.promedioPorMetaEmocional().subscribe(this.manejarRespuesta());
    } else if (this.authS.esUsuario()) {
      this.pS.miPromedioMeta().subscribe(this.manejarRespuesta());
    } else if (this.authS.esFamiliar()) {
      this.fuS.misVinculados().subscribe({
        next: (vinculados) => {
          if (vinculados.length === 0) {
            this.hasData = false;
            this.cdr.detectChanges();
            return;
          }
          this.pS
            .promedioMetaDeFamiliar(vinculados[0].idUsuario)
            .subscribe(this.manejarRespuesta());
        },
        error: () => {
          this.hasData = false;
          this.cdr.detectChanges();
        },
      });
    }
  }

  private manejarRespuesta() {
    return {
      next: (data: PromedioMetaEmocionalDTO[]) => {
        if (data.length > 0) {
          this.hasData = true;
          this.barChartLabels = data.map((item) => item.metaEmocional);
          this.barChartData = [
            {
              data: data.map((item) => Number(item.promedio.toFixed(1))),
              label: 'Promedio de control de ira',
              backgroundColor: ['#7fa98e', '#4f7a6d', '#d2653a', '#e0764a', '#a9b5ac'],
            },
          ];
        } else {
          this.hasData = false;
        }
        this.cdr.detectChanges();
      },
      error: (err: any) => {
        console.error('Error cargando reporte de promedio por meta:', err);
        this.hasData = false;
        this.cdr.detectChanges();
      },
    };
  }
}