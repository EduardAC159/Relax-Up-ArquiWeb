import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MetaEmocional } from '../../../models/meta-emocional';
import { Metaemocionalservice } from '../../../services/metaemocionalservice';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-meta-emocional-list',
  imports: [MatTableModule, MatIconModule, MatButtonModule],
  templateUrl: './meta-emocional-list.html',
  styleUrl: './meta-emocional-list.css',
})
export class MetaEmocionalList {
  dataSource: MatTableDataSource<MetaEmocional> = new MatTableDataSource();
  // El backend no expone DELETE para MetaEmocional, por eso no hay columna de accion
  displayedColumns: string[] = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6'];

  constructor(
    private meS: Metaemocionalservice,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.cargar();
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.cargar();
      }
    });
  }
  cargar() {
    this.meS.list().subscribe({
      next: (data) => {
        this.dataSource.data = data;
      },
    });
  }

}
