import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ChartDataset, ChartOptions, ChartType } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';
import { MatIconModule } from '@angular/material/icon';
import { Progresoservice } from '../../services/progresoservice';
import { Authservice } from '../../services/authservice';
import { Familiarusuarioservice } from '../../services/familiarusuarioservice';
import { CantidadNivelIraDTO } from '../../models/reportes';

@Component({
  selector: 'app-report65',
  imports: [BaseChartDirective, MatIconModule],
  templateUrl: './report65.html',
  styleUrl: './report65.css',
})
export class Report65 implements OnInit {
  hasData = false;
  barChartOptions: ChartOptions = {
    responsive: true,
  };
  barChartLegend = true;
  barChartLabels: string[] = [];
  barChartData: ChartDataset[] = [];
  barChartType: ChartType = 'bar';

  constructor(
    private pS: Progresoservice,
    private authS: Authservice,
    private fuS: Familiarusuarioservice,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnInit(): void {
    if (this.authS.esAdmin()) {
      this.pS.cantidadPorNivelControlIra().subscribe(this.manejarRespuesta());
    } else if (this.authS.esUsuario()) {
      this.pS.misNivelesControlIra().subscribe(this.manejarRespuesta());
    } else if (this.authS.esFamiliar()) {
      this.fuS.misVinculados().subscribe({
        next: (vinculados) => {
          if (vinculados.length === 0) {
            this.hasData = false;
            this.cdr.detectChanges();
            return;
          }
          this.pS
            .nivelesControlIraDeFamiliar(vinculados[0].idUsuario)
            .subscribe(this.manejarRespuesta());
        },
        error: () => {
          this.hasData = false;
          this.cdr.detectChanges();
        },
      });
    }
  }

  private manejarRespuesta() {
    return {
      next: (data: CantidadNivelIraDTO[]) => {
        if (data.length > 0) {
          this.hasData = true;
          this.barChartLabels = data.map((item) => `Nivel ${item.nivelControlIra}`);
          this.barChartData = [
            {
              data: data.map((item) => item.cantidad),
              label: 'Cantidad de registros',
              backgroundColor: ['#d2653a', '#e0764a', '#7fa98e', '#4f7a6d', '#a9b5ac', '#c9714f'],
            },
          ];
        } else {
          this.hasData = false;
        }
        this.cdr.detectChanges();
      },
      error: (err: any) => {
        console.error('Error cargando reporte de nivel de ira:', err);
        this.hasData = false;
        this.cdr.detectChanges();
      },
    };
  }
}