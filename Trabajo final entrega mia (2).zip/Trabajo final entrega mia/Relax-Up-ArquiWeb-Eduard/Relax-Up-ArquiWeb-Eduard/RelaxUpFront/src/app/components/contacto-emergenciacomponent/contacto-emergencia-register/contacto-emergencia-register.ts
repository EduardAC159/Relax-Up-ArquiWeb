import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { Router, RouterLink } from '@angular/router';
import { ContactoEmergencia } from '../../../models/contacto-emergencia';
import { ContactoEmergenciaservice } from '../../../services/contacto-emergenciaservice';

@Component({
  selector: 'app-contacto-emergencia-register',
  imports: [MatInputModule, MatButtonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './contacto-emergencia-register.html',
  styleUrl: './contacto-emergencia-register.css',
})
export class ContactoEmergenciaRegister {
  form: FormGroup = new FormGroup({});
  ce: ContactoEmergencia = new ContactoEmergencia();

  constructor(
    private ceS: ContactoEmergenciaservice,
    private router: Router,
    private formBuilder: FormBuilder,
  ) {}

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      nombre: ['', Validators.required],
      celular: ['', Validators.required],
      relacion: ['', Validators.required],
      idUsuario: ['', Validators.required],
    });
  }

  aceptar(): void {
    if (this.form.valid) {
      this.ce.nombre = this.form.value.nombre;
      this.ce.celular = this.form.value.celular;
      this.ce.relacion = this.form.value.relacion;
      this.ce.idUsuario = this.form.value.idUsuario;
      console.log(JSON.stringify(this.ce));
      this.ceS.insert(this.ce).subscribe({
        next: () => {
          this.router.navigate(['/contacto-emergencia/lista']);
        },
      });
    }
  }
}
