import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { Router, RouterLink } from '@angular/router';
import { Authservice } from '../../services/authservice';

@Component({
  selector: 'app-menucomponent',
  imports: [CommonModule, MatToolbarModule, MatButtonModule, MatIconModule, MatMenuModule, RouterLink],
  templateUrl: './menucomponent.html',
  styleUrl: './menucomponent.css',
})
export class Menucomponent {
  constructor(
    private authS: Authservice,
    private router: Router,
  ) {}

  get esAdmin(): boolean {
    return this.authS.esAdmin();
  }

  get username(): string | null {
    return this.authS.obtenerUsername();
  }

  cerrarSesion(): void {
    this.authS.cerrarSesion();
    this.router.navigate(['/login']);
  }

  get esUsuario(): boolean {
    return this.authS.esUsuario();
  }

  get esFamiliar(): boolean {
    return this.authS.esFamiliar();
  }
  
}