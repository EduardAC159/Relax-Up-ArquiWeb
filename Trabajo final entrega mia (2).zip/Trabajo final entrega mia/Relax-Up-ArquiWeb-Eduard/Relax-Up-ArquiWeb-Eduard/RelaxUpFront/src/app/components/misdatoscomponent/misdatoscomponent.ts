import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatTabsModule } from '@angular/material/tabs';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { Emergenciaservice } from '../../services/emergenciaservice';
import { Metaemocionalservice } from '../../services/metaemocionalservice';
import { Progresoservice } from '../../services/progresoservice';
import { Emergencia } from '../../models/emergencia';
import { MetaEmocional } from '../../models/meta-emocional';
import { Progreso } from '../../models/progreso';

function formatearFecha(fecha: Date | string): string {
  const d = fecha instanceof Date ? fecha : new Date(fecha);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

@Component({
  selector: 'app-misdatoscomponent',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatTabsModule,
    MatIconModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatDatepickerModule,
  ],
  templateUrl: './misdatoscomponent.html',
  styleUrl: './misdatoscomponent.css',
})
export class Misdatoscomponent implements OnInit {
  emergencias: Emergencia[] = [];
  metas: MetaEmocional[] = [];
  progresos: Progreso[] = [];
  cargado = false;

  form: FormGroup;
  guardando = false;

  formMeta: FormGroup;
  guardandoMeta = false;

  mensajeExito = '';
  mensajeError = '';

  constructor(
    private emS: Emergenciaservice,
    private meS: Metaemocionalservice,
    private pS: Progresoservice,
    private cdr: ChangeDetectorRef,
    private fb: FormBuilder,
  ) {
    this.form = this.fb.group({
      idMetaEmocional: ['', Validators.required],
      nivelControlIra: ['', [Validators.required, Validators.min(1), Validators.max(10)]],
      fecha: [new Date(), Validators.required],
      observaciones: [''],
    });

    this.formMeta = this.fb.group({
      descripcion: ['', Validators.required],
      fechaInicio: [new Date(), Validators.required],
      fechaFin: [null, Validators.required],
      estado: ['En progreso', Validators.required],
    });
  }

  ngOnInit(): void {
    this.emS.mias().subscribe({
      next: (data) => {
        this.emergencias = data;
        this.cdr.detectChanges();
      },
      error: (err) => console.error('Error cargando mis emergencias:', err),
    });

    this.cargarMetasYProgreso();
  }

  cargarMetasYProgreso(): void {
    this.meS.mias().subscribe({
      next: (data) => {
        this.metas = data;
        this.cdr.detectChanges();
      },
      error: (err) => console.error('Error cargando mis metas:', err),
    });

    this.pS.mias().subscribe({
      next: (data) => {
        this.progresos = data;
        this.cargado = true;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('Error cargando mi progreso:', err);
        this.cargado = true;
        this.cdr.detectChanges();
      },
    });
  }

  registrarProgreso(): void {
    this.mensajeExito = '';
    this.mensajeError = '';
    if (this.form.invalid) return;

    this.guardando = true;
    const p: Progreso = {
      ...this.form.value,
      fecha: formatearFecha(this.form.value.fecha),
    };

    this.pS.registrarMio(p).subscribe({
      next: () => {
        this.mensajeExito = 'Progreso registrado correctamente.';
        this.guardando = false;
        this.form.reset({
          idMetaEmocional: '',
          nivelControlIra: '',
          fecha: new Date(),
          observaciones: '',
        });
        this.cargarMetasYProgreso();
      },
      error: () => {
        this.mensajeError = 'No se pudo registrar el progreso.';
        this.guardando = false;
        this.cdr.detectChanges();
      },
    });
  }

  registrarMeta(): void {
    this.mensajeExito = '';
    this.mensajeError = '';
    if (this.formMeta.invalid) return;

    this.guardandoMeta = true;
    const me: MetaEmocional = {
      ...this.formMeta.value,
      fechaInicio: formatearFecha(this.formMeta.value.fechaInicio),
      fechaFin: formatearFecha(this.formMeta.value.fechaFin),
    };

    this.meS.registrarMia(me).subscribe({
      next: () => {
        this.mensajeExito = 'Meta emocional registrada correctamente.';
        this.guardandoMeta = false;
        this.formMeta.reset({
          descripcion: '',
          fechaInicio: new Date(),
          fechaFin: null,
          estado: 'En progreso',
        });
        this.meS.mias().subscribe((data) => {
          this.metas = data;
          this.cdr.detectChanges();
        });
      },
      error: () => {
        this.mensajeError = 'No se pudo registrar la meta.';
        this.guardandoMeta = false;
        this.cdr.detectChanges();
      },
    });
  }
}