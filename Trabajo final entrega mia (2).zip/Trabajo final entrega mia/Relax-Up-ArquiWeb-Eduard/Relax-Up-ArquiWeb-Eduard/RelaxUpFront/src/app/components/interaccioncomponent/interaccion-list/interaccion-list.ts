import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Interaccion } from '../../../models/interaccion';
import { Interaccionservice } from '../../../services/interaccionservice';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-interaccion-list',
  imports: [MatTableModule, MatIconModule, MatButtonModule],
  templateUrl: './interaccion-list.html',
  styleUrl: './interaccion-list.css',
})
export class InteraccionList {
    dataSource: MatTableDataSource<Interaccion> = new MatTableDataSource();
  displayedColumns: string[] = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6'];

  constructor(
    private iS: Interaccionservice,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.cargar();
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.cargar();
      }
    });
  }
  cargar() {
    this.iS.list().subscribe({
      next: (data) => {
        this.dataSource.data = data;
      },
    });
  }
  eliminar(id: number) {
    this.iS.delete(id).subscribe(() => {
      this.iS.list().subscribe((data) => {
        this.dataSource.data = data;
      });
    });
  }
}
