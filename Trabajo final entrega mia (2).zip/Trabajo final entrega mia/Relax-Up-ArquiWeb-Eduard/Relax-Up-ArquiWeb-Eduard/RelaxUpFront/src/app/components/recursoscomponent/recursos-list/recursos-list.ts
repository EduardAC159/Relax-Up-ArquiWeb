import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Recursos } from '../../../models/recursos';
import { Recursosservice } from '../../../services/recursosservice';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-recursos-list',
  imports: [MatTableModule, MatIconModule, MatButtonModule],
  templateUrl: './recursos-list.html',
  styleUrl: './recursos-list.css',
})
export class RecursosList {
    dataSource: MatTableDataSource<Recursos> = new MatTableDataSource();
  displayedColumns: string[] = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6'];

  constructor(
    private recS: Recursosservice,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.cargar();
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.cargar();
      }
    });
  }
  cargar() {
    this.recS.list().subscribe({
      next: (data) => {
        this.dataSource.data = data;
      },
    });
  }
  eliminar(id: number) {
    this.recS.delete(id).subscribe(() => {
      this.recS.list().subscribe((data) => {
        this.dataSource.data = data;
      });
    });
  }

}
