import { Component } from '@angular/core';
import { ActivatedRoute, RouterOutlet } from '@angular/router';
import { MetaEmocionalList } from './meta-emocional-list/meta-emocional-list';

@Component({
  selector: 'app-metaemocionalcomponent',
  imports: [RouterOutlet, MetaEmocionalList],
  templateUrl: './metaemocionalcomponent.html',
  styleUrl: './metaemocionalcomponent.css',
})
export class Metaemocionalcomponent {
  constructor(public route: ActivatedRoute) {}
}
