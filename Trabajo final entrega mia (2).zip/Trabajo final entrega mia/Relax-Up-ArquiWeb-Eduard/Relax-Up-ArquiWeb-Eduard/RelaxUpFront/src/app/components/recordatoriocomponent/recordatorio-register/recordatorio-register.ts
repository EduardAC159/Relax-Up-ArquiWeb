import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { Router, RouterLink } from '@angular/router';
import { Recordatorio } from '../../../models/recordatorio';
import { Recordatorioservice } from '../../../services/recordatorioservice';

@Component({
  selector: 'app-recordatorio-register',
  imports: [MatInputModule, MatButtonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './recordatorio-register.html',
  styleUrl: './recordatorio-register.css',
})
export class RecordatorioRegister {
    form: FormGroup = new FormGroup({});
  re: Recordatorio = new Recordatorio();

  constructor(
    private reS: Recordatorioservice,
    private router: Router,
    private formBuilder: FormBuilder,
  ) {}

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      mensaje: ['', Validators.required],
      fechaHora: ['', Validators.required],
      tipo: ['', Validators.required],
      idUsuario: ['', Validators.required],
    });
  }

  aceptar(): void {
    if (this.form.valid) {
      this.re.mensaje = this.form.value.mensaje;
      this.re.fechaHora = this.form.value.fechaHora;
      this.re.tipo = this.form.value.tipo;
      this.re.idUsuario = this.form.value.idUsuario;
      console.log(JSON.stringify(this.re));
      this.reS.insert(this.re).subscribe({
        next: () => {
          this.router.navigate(['/recordatorio/lista']);
        },
      });
    }
  }

}
