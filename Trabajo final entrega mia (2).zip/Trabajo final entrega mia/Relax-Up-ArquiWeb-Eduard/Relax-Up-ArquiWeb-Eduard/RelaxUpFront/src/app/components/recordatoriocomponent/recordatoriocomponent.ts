import { Component } from '@angular/core';
import { RecordatorioList } from './recordatorio-list/recordatorio-list';
import { ActivatedRoute, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-recordatoriocomponent',
  imports: [RouterOutlet, RecordatorioList],
  templateUrl: './recordatoriocomponent.html',
  styleUrl: './recordatoriocomponent.css',
})
export class Recordatoriocomponent {
  constructor(public route: ActivatedRoute) {}
}
