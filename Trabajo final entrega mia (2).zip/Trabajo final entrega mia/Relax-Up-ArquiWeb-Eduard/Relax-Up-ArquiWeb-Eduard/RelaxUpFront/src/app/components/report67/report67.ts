import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Comunidadservice } from '../../services/comunidadservice';

@Component({
  selector: 'app-report67',
  imports: [CommonModule],
  templateUrl: './report67.html',
  styleUrl: './report67.css',
})
export class Report67 implements OnInit {
  cantidad = 0;
  cargado = false;

  constructor(
    private cS: Comunidadservice,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnInit(): void {
    this.cS.cantidadRegistradas().subscribe({
      next: (data) => {
        this.cantidad = data;
        this.cargado = true;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('Error cargando cantidad de comunidades:', err);
        this.cargado = true;
        this.cdr.detectChanges();
      },
    });
  }
}