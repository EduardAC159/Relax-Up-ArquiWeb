import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Recordatorio } from '../../../models/recordatorio';
import { Recordatorioservice } from '../../../services/recordatorioservice';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-recordatorio-list',
  imports: [MatTableModule, MatIconModule, MatButtonModule],
  templateUrl: './recordatorio-list.html',
  styleUrl: './recordatorio-list.css',
})
export class RecordatorioList {
  dataSource: MatTableDataSource<Recordatorio> = new MatTableDataSource();
  displayedColumns: string[] = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6'];

  constructor(
    private reS: Recordatorioservice,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.cargar();
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.cargar();
      }
    });
  }
  cargar() {
    this.reS.list().subscribe({
      next: (data) => {
        this.dataSource.data = data;
      },
    });
  }
  eliminar(id: number) {
    this.reS.delete(id).subscribe(() => {
      this.reS.list().subscribe((data) => {
        this.dataSource.data = data;
      });
    });
  }

}
