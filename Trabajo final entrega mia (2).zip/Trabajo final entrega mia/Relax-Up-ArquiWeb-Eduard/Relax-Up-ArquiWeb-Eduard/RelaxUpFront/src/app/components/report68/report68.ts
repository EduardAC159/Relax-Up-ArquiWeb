import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ContactoEmergenciaservice } from '../../services/contacto-emergenciaservice';
import { CantidadParentescoDTO } from '../../models/reportes';

@Component({
  selector: 'app-report68',
  imports: [CommonModule, MatIconModule],
  templateUrl: './report68.html',
  styleUrl: './report68.css',
})
export class Report68 implements OnInit {
  parentescos: CantidadParentescoDTO[] = [];
  hasData = false;

  constructor(
    private ceS: ContactoEmergenciaservice,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnInit(): void {
    this.ceS.cantidadPorParentesco().subscribe({
      next: (data) => {
        this.parentescos = data;
        this.hasData = data.length > 0;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('Error cargando contactos por parentesco:', err);
        this.hasData = false;
        this.cdr.detectChanges();
      },
    });
  }

  // Escala cada barra respecto al valor máximo del set
  porcentaje(item: CantidadParentescoDTO): number {
    const max = Math.max(...this.parentescos.map((p) => p.cantidad), 1);
    return Math.round((item.cantidad / max) * 100);
  }
}