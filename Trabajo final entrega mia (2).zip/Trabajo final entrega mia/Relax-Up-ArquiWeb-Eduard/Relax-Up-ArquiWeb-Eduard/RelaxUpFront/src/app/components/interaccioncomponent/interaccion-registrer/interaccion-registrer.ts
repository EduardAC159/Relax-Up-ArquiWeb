import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { Router, RouterLink } from '@angular/router';
import { Interaccion } from '../../../models/interaccion';
import { Interaccionservice } from '../../../services/interaccionservice';

@Component({
  selector: 'app-interaccion-registrer',
  imports: [    MatInputModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    RouterLink],
  templateUrl: './interaccion-registrer.html',
  styleUrl: './interaccion-registrer.css',
})
export class InteraccionRegistrer {
  form: FormGroup = new FormGroup({});
  inte: Interaccion = new Interaccion();

  constructor(
    private iS: Interaccionservice,
    private router: Router,
    private formBuilder: FormBuilder,
  ) {}

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      mensaje: ['', Validators.required],
      fecha: ['', Validators.required],
      idUsuario: ['', Validators.required],
      idComunidad: ['', Validators.required],
    });
  }

  aceptar(): void {
    if (this.form.valid) {
      this.inte.mensaje = this.form.value.mensaje;
      this.inte.fecha = this.form.value.fecha;
      this.inte.idUsuario = this.form.value.idUsuario;
      this.inte.idComunidad = this.form.value.idComunidad;
      console.log(JSON.stringify(this.inte));
      this.iS.insert(this.inte).subscribe({
        next: () => {
          this.router.navigate(['/interaccion/lista']);
        },
      });
    }
  }
}
