import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Progreso } from '../../../models/progreso';
import { Progresoservice } from '../../../services/progresoservice';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-progreso-list',
  imports: [MatTableModule, MatIconModule, MatButtonModule],
  templateUrl: './progreso-list.html',
  styleUrl: './progreso-list.css',
})
export class ProgresoList {
  dataSource: MatTableDataSource<Progreso> = new MatTableDataSource();
  // El backend no expone DELETE para Progreso, por eso no hay columna de accion
  displayedColumns: string[] = ['c1', 'c2', 'c3', 'c4', 'c5'];

  constructor(
    private pS: Progresoservice,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.cargar();
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.cargar();
      }
    });
  }
  cargar() {
    this.pS.list().subscribe({
      next: (data) => {
        this.dataSource.data = data;
      },
    });
  }

}
