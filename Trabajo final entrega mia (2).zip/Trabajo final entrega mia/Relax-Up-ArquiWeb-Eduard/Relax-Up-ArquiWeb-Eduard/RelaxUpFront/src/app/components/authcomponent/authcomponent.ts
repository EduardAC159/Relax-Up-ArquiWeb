import { Component } from '@angular/core';

@Component({
  selector: 'app-authcomponent',
  imports: [],
  templateUrl: './authcomponent.html',
  styleUrl: './authcomponent.css',
})
export class Authcomponent {}
