import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatTabsModule } from '@angular/material/tabs';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { Familiarusuarioservice } from '../../services/familiarusuarioservice';
import { Progresoservice } from '../../services/progresoservice';
import { Emergenciaservice } from '../../services/emergenciaservice';
import { Metaemocionalservice } from '../../services/metaemocionalservice';
import { Usuario } from '../../models/usuario';
import { MetaEmocional } from '../../models/meta-emocional';
import { Progreso } from '../../models/progreso';
import { Emergencia } from '../../models/emergencia';

function formatearFecha(fecha: Date | string): string {
  const d = fecha instanceof Date ? fecha : new Date(fecha);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

@Component({
  selector: 'app-familiarpanelcomponent',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatTabsModule,
    MatIconModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatDatepickerModule,
  ],
  templateUrl: './familiarpanelcomponent.html',
  styleUrl: './familiarpanelcomponent.css',
})
export class Familiarpanelcomponent implements OnInit {
  vinculados: Usuario[] = [];
  usuarioSeleccionado: Usuario | null = null;
  metas: MetaEmocional[] = [];
  progresos: Progreso[] = [];
  emergencias: Emergencia[] = [];
  cargado = false;

  formProgreso: FormGroup;
  formEmergencia: FormGroup;
  guardandoProgreso = false;
  guardandoEmergencia = false;
  mensajeExito = '';
  mensajeError = '';

  constructor(
    private fuS: Familiarusuarioservice,
    private pS: Progresoservice,
    private emS: Emergenciaservice,
    private meS: Metaemocionalservice,
    private cdr: ChangeDetectorRef,
    private fb: FormBuilder,
  ) {
    this.formProgreso = this.fb.group({
      idMetaEmocional: ['', Validators.required],
      nivelControlIra: ['', [Validators.required, Validators.min(1), Validators.max(10)]],
      fecha: [new Date(), Validators.required],
      observaciones: [''],
    });

    this.formEmergencia = this.fb.group({
      tipo: ['', Validators.required],
      descripcion: ['', Validators.required],
      fecha: [new Date(), Validators.required],
    });
  }

  ngOnInit(): void {
    this.fuS.misVinculados().subscribe({
      next: (data) => {
        this.vinculados = data;
        if (data.length > 0) {
          this.seleccionarUsuario(data[0]);
        } else {
          this.cargado = true;
        }
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('Error cargando vinculados:', err);
        this.cargado = true;
        this.cdr.detectChanges();
      },
    });
  }

  seleccionarUsuario(u: Usuario): void {
    this.usuarioSeleccionado = u;
    this.cargarDatosDeUsuario(u.idUsuario);
  }

  cargarDatosDeUsuario(usuarioId: number): void {
    this.meS.deMiFamiliar(usuarioId).subscribe({
      next: (data) => {
        this.metas = data;
        this.cdr.detectChanges();
      },
      error: (err) => console.error('Error cargando metas del usuario:', err),
    });

    this.pS.deMiFamiliar(usuarioId).subscribe({
      next: (data) => {
        this.progresos = data;
        this.cdr.detectChanges();
      },
      error: (err) => console.error('Error cargando progreso del usuario:', err),
    });

    this.emS.deMiFamiliar(usuarioId).subscribe({
      next: (data) => {
        this.emergencias = data;
        this.cargado = true;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('Error cargando emergencias del usuario:', err);
        this.cargado = true;
        this.cdr.detectChanges();
      },
    });
  }

  registrarProgreso(): void {
    this.mensajeExito = '';
    this.mensajeError = '';
    if (this.formProgreso.invalid || !this.usuarioSeleccionado) return;

    this.guardandoProgreso = true;
    const p: Progreso = {
      ...this.formProgreso.value,
      fecha: formatearFecha(this.formProgreso.value.fecha),
    };

    this.pS.registrarParaUsuario(this.usuarioSeleccionado.idUsuario, p).subscribe({
      next: () => {
        this.mensajeExito = 'Progreso registrado correctamente.';
        this.guardandoProgreso = false;
        this.formProgreso.reset({
          idMetaEmocional: '',
          nivelControlIra: '',
          fecha: new Date(),
          observaciones: '',
        });
        this.cargarDatosDeUsuario(this.usuarioSeleccionado!.idUsuario);
      },
      error: () => {
        this.mensajeError = 'No se pudo registrar el progreso.';
        this.guardandoProgreso = false;
        this.cdr.detectChanges();
      },
    });
  }

  registrarEmergencia(): void {
    this.mensajeExito = '';
    this.mensajeError = '';
    if (this.formEmergencia.invalid || !this.usuarioSeleccionado) return;

    this.guardandoEmergencia = true;
    const e: Emergencia = {
      ...this.formEmergencia.value,
      fecha: formatearFecha(this.formEmergencia.value.fecha),
    };

    this.emS.registrarParaUsuario(this.usuarioSeleccionado.idUsuario, e).subscribe({
      next: () => {
        this.mensajeExito = 'Emergencia registrada correctamente.';
        this.guardandoEmergencia = false;
        this.formEmergencia.reset({
          tipo: '',
          descripcion: '',
          fecha: new Date(),
        });
        this.cargarDatosDeUsuario(this.usuarioSeleccionado!.idUsuario);
      },
      error: () => {
        this.mensajeError = 'No se pudo registrar la emergencia.';
        this.guardandoEmergencia = false;
        this.cdr.detectChanges();
      },
    });
  }
}