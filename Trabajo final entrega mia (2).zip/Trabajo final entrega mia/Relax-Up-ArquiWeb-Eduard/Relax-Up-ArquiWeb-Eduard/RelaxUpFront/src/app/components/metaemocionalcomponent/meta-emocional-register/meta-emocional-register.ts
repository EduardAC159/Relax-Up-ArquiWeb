import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { Router, RouterLink } from '@angular/router';
import { MetaEmocional } from '../../../models/meta-emocional';
import { Metaemocionalservice } from '../../../services/metaemocionalservice';

@Component({
  selector: 'app-meta-emocional-register',
  imports: [    MatInputModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    RouterLink],
  templateUrl: './meta-emocional-register.html',
  styleUrl: './meta-emocional-register.css',
})
export class MetaEmocionalRegister {
  form: FormGroup = new FormGroup({});
  me: MetaEmocional = new MetaEmocional();

  constructor(
    private meS: Metaemocionalservice,
    private router: Router,
    private formBuilder: FormBuilder,
  ) {}

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      descripcion: ['', Validators.required],
      fechaInicio: ['', Validators.required],
      fechaFin: ['', Validators.required],
      estado: ['', Validators.required],
      idUsuario: ['', Validators.required],
    });
  }

  aceptar(): void {
    if (this.form.valid) {
      this.me.descripcion = this.form.value.descripcion;
      this.me.fechaInicio = this.form.value.fechaInicio;
      this.me.fechaFin = this.form.value.fechaFin;
      this.me.estado = this.form.value.estado;
      this.me.idUsuario = this.form.value.idUsuario;
      console.log(JSON.stringify(this.me));
      this.meS.insert(this.me).subscribe({
        next: () => {
          this.router.navigate(['/meta-emocional/lista']);
        },
      });
    }
  }

}
