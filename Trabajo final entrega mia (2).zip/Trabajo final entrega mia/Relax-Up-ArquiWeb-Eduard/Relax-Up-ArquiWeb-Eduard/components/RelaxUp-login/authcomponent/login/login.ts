import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { Authservice } from '../../../services/authservice';
import { User } from '../../../models/user';

@Component({
  selector: 'app-login',
  imports: [CommonModule, MatInputModule, MatButtonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {
  form: FormGroup;
  error: string = '';

  constructor(
    private authS: Authservice,
    private router: Router,
    private formBuilder: FormBuilder,
  ) {
    this.form = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  ingresar(): void {
    this.error = '';
    if (this.form.valid) {
      const user: User = this.form.value;
      this.authS.login(user).subscribe({
        next: (res) => {
          this.authS.guardarToken(res.jwttoken);
          this.router.navigate(['/homes']);
        },
        error: () => {
          this.error = 'Usuario o contraseña incorrectos.';
        },
      });
    }
  }
}
