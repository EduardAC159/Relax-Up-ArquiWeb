import { Routes } from '@angular/router';
import { Homecomponent } from './components/homecomponent/homecomponent';
import { Comunidadcomponent } from './components/comunidadcomponent/comunidadcomponent';
import { LiteralMapSpreadAssignment } from '@angular/compiler';
import { ComunidadList } from './components/comunidadcomponent/comunidad-list/comunidad-list';
import { ComunidadRegister } from './components/comunidadcomponent/comunidad-register/comunidad-register';
import { Usuariocomponent } from './components/usuariocomponent/usuariocomponent';
import { UsuarioList } from './components/usuariocomponent/usuario-list/usuario-list';
import { UsuarioRegister } from './components/usuariocomponent/usuario-register/usuario-register';
import { Emergenciacomponent } from './components/emergenciacomponent/emergenciacomponent';
import { EmergenciaList } from './components/emergenciacomponent/emergencia-list/emergencia-list';
import { EmergenciaRegister } from './components/emergenciacomponent/emergencia-register/emergencia-register';
import { ContactoEmergenciacomponent } from './components/contacto-emergenciacomponent/contacto-emergenciacomponent';
import { ContactoEmergenciaList } from './components/contacto-emergenciacomponent/contacto-emergencia-list/contacto-emergencia-list';
import { ContactoEmergenciaRegister } from './components/contacto-emergenciacomponent/contacto-emergencia-register/contacto-emergencia-register';
import { Login } from './components/authcomponent/login/login';
import { Recursoscomponent } from './components/recursoscomponent/recursoscomponent';
import { RecursosList } from './components/recursoscomponent/recursos-list/recursos-list';
import { RecursosRegister } from './components/recursoscomponent/recursos-register/recursos-register';
import { Recordatoriocomponent } from './components/recordatoriocomponent/recordatoriocomponent';
import { RecordatorioList } from './components/recordatoriocomponent/recordatorio-list/recordatorio-list';
import { RecordatorioRegister } from './components/recordatoriocomponent/recordatorio-register/recordatorio-register';
import { Interaccioncomponent } from './components/interaccioncomponent/interaccioncomponent';
import { InteraccionList } from './components/interaccioncomponent/interaccion-list/interaccion-list';
import { InteraccionRegister } from './components/interaccioncomponent/interaccion-register/interaccion-register';
import { Metaemocionalcomponent } from './components/metaemocionalcomponent/metaemocionalcomponent';
import { MetaEmocionalList } from './components/metaemocionalcomponent/meta-emocional-list/meta-emocional-list';
import { MetaEmocionalRegister } from './components/metaemocionalcomponent/meta-emocional-register/meta-emocional-register';
import { Progresocomponent } from './components/progresocomponent/progresocomponent';
import { ProgresoList } from './components/progresocomponent/progreso-list/progreso-list';
import { ProgresoRegister } from './components/progresocomponent/progreso-register/progreso-register';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'homes',
    pathMatch: 'full',
  },
  {
    path: 'login',
    component: Login,
  },
  {
    path: 'homes',
    component: Homecomponent,
  },
  {
    path: 'comunidad',
    component: Comunidadcomponent,
    children: [
      {
        path: 'lista',
        component: ComunidadList,
      },
      {
        path: 'news',
        component: ComunidadRegister,
      },
    ],
  },
  {
    path: 'usuario',
    component: Usuariocomponent,
    children: [
      {
        path: 'lista',
        component: UsuarioList,
      },
      {
        path: 'news',
        component: UsuarioRegister,
      },
    ],
  },
  {
    path: 'emergencia',
    component: Emergenciacomponent,
    children: [
      {
        path: 'lista',
        component: EmergenciaList,
      },
      {
        path: 'news',
        component: EmergenciaRegister,
      },
    ],
  },
  {
    path: 'contacto-emergencia',
    component: ContactoEmergenciacomponent,
    children: [
      {
        path: 'lista',
        component: ContactoEmergenciaList,
      },
      {
        path: 'news',
        component: ContactoEmergenciaRegister,
      },
    ],
  },
  {
    path: 'recursos',
    component: Recursoscomponent,
    children: [
      {
        path: 'lista',
        component: RecursosList,
      },
      {
        path: 'news',
        component: RecursosRegister,
      },
    ],
  },
  {
    path: 'recordatorio',
    component: Recordatoriocomponent,
    children: [
      {
        path: 'lista',
        component: RecordatorioList,
      },
      {
        path: 'news',
        component: RecordatorioRegister,
      },
    ],
  },
  {
    path: 'interaccion',
    component: Interaccioncomponent,
    children: [
      {
        path: 'lista',
        component: InteraccionList,
      },
      {
        path: 'news',
        component: InteraccionRegister,
      },
    ],
  },
  {
    path: 'meta-emocional',
    component: Metaemocionalcomponent,
    children: [
      {
        path: 'lista',
        component: MetaEmocionalList,
      },
      {
        path: 'news',
        component: MetaEmocionalRegister,
      },
    ],
  },
  {
    path: 'progreso',
    component: Progresocomponent,
    children: [
      {
        path: 'lista',
        component: ProgresoList,
      },
      {
        path: 'news',
        component: ProgresoRegister,
      },
    ],
  },
];
