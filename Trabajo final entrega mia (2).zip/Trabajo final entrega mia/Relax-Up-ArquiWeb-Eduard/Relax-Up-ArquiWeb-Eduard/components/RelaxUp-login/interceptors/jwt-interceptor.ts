import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Authservice } from '../services/authservice';

// Agrega "Authorization: Bearer <token>" a toda peticion saliente,
// salvo /login y /api/User/nuevo, que son publicas en el backend.
export const jwtInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(Authservice);
  const token = authService.obtenerToken();

  const esPublica = req.url.endsWith('/login') || req.url.endsWith('/api/User/nuevo');

  if (token && !esPublica) {
    const cloned = req.clone({
      setHeaders: { Authorization: `Bearer ${token}` },
    });
    return next(cloned);
  }

  return next(req);
};
