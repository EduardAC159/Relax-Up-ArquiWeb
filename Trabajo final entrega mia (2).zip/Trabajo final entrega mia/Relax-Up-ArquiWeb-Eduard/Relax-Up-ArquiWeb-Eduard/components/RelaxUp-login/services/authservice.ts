import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment.development';
import { User } from '../models/user';

const base_url = environment.base;
const TOKEN_KEY = 'relaxup_token';

@Injectable({
  providedIn: 'root',
})
export class Authservice {
  private url = `${base_url}`;

  constructor(private http: HttpClient) {}

  // POST /login -> { jwttoken: string }
  login(user: User) {
    return this.http.post<{ jwttoken: string }>(`${this.url}/login`, user);
  }

  // POST /api/User/nuevo -> crea la cuenta (ruta pública)
  register(user: User) {
    return this.http.post(`${this.url}/api/User/nuevo`, user);
  }

  guardarToken(token: string): void {
    localStorage.setItem(TOKEN_KEY, token);
  }

  obtenerToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  estaAutenticado(): boolean {
    return !!this.obtenerToken();
  }

  cerrarSesion(): void {
    localStorage.removeItem(TOKEN_KEY);
  }
}
