import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule, provideNativeDateAdapter } from '@angular/material/core';
import { Router, RouterLink } from '@angular/router';
import { Progreso } from '../../../models/progreso';
import { Progresoservice } from '../../../services/progresoservice';

@Component({
  selector: 'app-progreso-register',
  providers: [provideNativeDateAdapter()],
  imports: [
    MatInputModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    RouterLink,
  ],
  templateUrl: './progreso-register.html',
  styleUrl: './progreso-register.css',
})
export class ProgresoRegister implements OnInit {
  form: FormGroup = new FormGroup({});
  pro: Progreso = new Progreso();

  constructor(
    private pS: Progresoservice,
    private router: Router,
    private formBuilder: FormBuilder,
  ) {}

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      nivelControlIra: ['', Validators.required],
      fecha: ['', Validators.required],
      observaciones: ['', Validators.required],
      idMetaEmocional: ['', Validators.required],
    });
  }

  aceptar(): void {
    if (this.form.valid) {
      this.pro.nivelControlIra = this.form.value.nivelControlIra;
      this.pro.fecha = this.form.value.fecha;
      this.pro.observaciones = this.form.value.observaciones;
      this.pro.idMetaEmocional = this.form.value.idMetaEmocional;
      console.log(JSON.stringify(this.pro));
      this.pS.insert(this.pro).subscribe({
        next: () => {
          this.router.navigate(['/progreso/lista']);
        },
      });
    }
  }
}
