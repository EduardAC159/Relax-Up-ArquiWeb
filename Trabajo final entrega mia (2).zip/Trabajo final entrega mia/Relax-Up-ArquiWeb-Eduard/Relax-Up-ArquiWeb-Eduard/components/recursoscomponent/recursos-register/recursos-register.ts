import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { Router, RouterLink } from '@angular/router';
import { Recursos } from '../../../models/recursos';
import { Recursosservice } from '../../../services/recursosservice';

@Component({
  selector: 'app-recursos-register',
  imports: [MatInputModule, MatButtonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './recursos-register.html',
  styleUrl: './recursos-register.css',
})
export class RecursosRegister implements OnInit {
  form: FormGroup = new FormGroup({});
  rec: Recursos = new Recursos();

  constructor(
    private recS: Recursosservice,
    private router: Router,
    private formBuilder: FormBuilder,
  ) {}

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      titulo: ['', Validators.required],
      tipo: ['', Validators.required],
      enlace: ['', Validators.required],
      idUsuario: ['', Validators.required],
    });
  }

  aceptar(): void {
    if (this.form.valid) {
      this.rec.titulo = this.form.value.titulo;
      this.rec.tipo = this.form.value.tipo;
      this.rec.enlace = this.form.value.enlace;
      this.rec.idUsuario = this.form.value.idUsuario;
      console.log(JSON.stringify(this.rec));
      this.recS.insert(this.rec).subscribe({
        next: () => {
          this.router.navigate(['/recursos/lista']);
        },
      });
    }
  }
}
