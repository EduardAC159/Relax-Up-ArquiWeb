import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { Progreso } from '../models/progreso';
import { Observable } from 'rxjs';
import { CantidadNivelIraDTO, PromedioMetaEmocionalDTO } from '../models/reportes';

const base_url = environment.base;

@Injectable({
  providedIn: 'root',
})
export class Progresoservice {
  private url = `${base_url}/api/Progreso`;
  constructor(private http: HttpClient) {}

  // El backend no expone DELETE para Progreso
  list() {
    return this.http.get<Progreso[]>(`${this.url}`);
  }
  insert(p: Progreso) {
    return this.http.post(`${this.url}/nuevo`, p);
  }
  cantidadPorNivelControlIra(): Observable<CantidadNivelIraDTO[]> {
    return this.http.get<CantidadNivelIraDTO[]>(`${this.url}/CantidadPorNivelControlIra`);
  }
  promedioPorMetaEmocional(): Observable<PromedioMetaEmocionalDTO[]> {
    return this.http.get<PromedioMetaEmocionalDTO[]>(`${this.url}/PromedioPorMetaEmocional`);
  }
  mias() {
    return this.http.get<Progreso[]>(`${this.url}/mias`);
  }
  registrarMio(p: Progreso) {
    return this.http.post(`${this.url}/mia`, p);
  }
  registrarParaUsuario(usuarioId: number, p: Progreso) {
    return this.http.post(`${this.url}/registrar-para/${usuarioId}`, p);
  }
  deMiFamiliar(usuarioId: number) {
    return this.http.get<Progreso[]>(`${this.url}/deMiFamiliar/${usuarioId}`);
  }
}
