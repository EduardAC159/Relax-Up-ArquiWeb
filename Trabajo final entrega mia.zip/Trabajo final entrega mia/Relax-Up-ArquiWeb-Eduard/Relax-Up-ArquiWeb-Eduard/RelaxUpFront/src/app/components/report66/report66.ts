import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ChartDataset, ChartOptions, ChartType } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';
import { MatIconModule } from '@angular/material/icon';
import { Progresoservice } from '../../services/progresoservice';

@Component({
  selector: 'app-report66',
  imports: [BaseChartDirective, MatIconModule],
  templateUrl: './report66.html',
  styleUrl: './report66.css',
})
export class Report66 implements OnInit {
  hasData = false;
  barChartOptions: ChartOptions = {
    responsive: true,
  };
  barChartLegend = true;
  barChartLabels: string[] = [];
  barChartData: ChartDataset[] = [];
  barChartType: ChartType = 'bar';

  constructor(
    private pS: Progresoservice,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnInit(): void {
    this.pS.promedioPorMetaEmocional().subscribe({
      next: (data) => {
        if (data.length > 0) {
          this.hasData = true;
          this.barChartLabels = data.map((item) => item.metaEmocional);
          this.barChartData = [
            {
              data: data.map((item) => Number(item.promedio.toFixed(1))),
              label: 'Promedio de control de ira',
              backgroundColor: ['#7fa98e', '#4f7a6d', '#d2653a', '#e0764a', '#a9b5ac'],
            },
          ];
        } else {
          this.hasData = false;
        }
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('Error cargando reporte de promedio por meta:', err);
        this.hasData = false;
        this.cdr.detectChanges();
      },
    });
  }
}