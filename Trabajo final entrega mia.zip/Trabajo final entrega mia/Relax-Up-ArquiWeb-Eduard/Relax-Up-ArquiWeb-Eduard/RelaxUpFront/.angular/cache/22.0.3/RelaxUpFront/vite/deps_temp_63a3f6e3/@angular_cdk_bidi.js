import {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
} from "./chunk-UFAOIE2A.js";
import "./chunk-XAKRGN6T.js";
export {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
};
