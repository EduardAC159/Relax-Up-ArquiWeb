package pe.edu.upc.relaxup.Dtos;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class RegistroExtremoDTO {
    private int idProgreso;
    private LocalDate fecha;
    private LocalDateTime hora;
    private int nivelControlIra;
    private String observaciones;
    private String metaEmocional;

    public RegistroExtremoDTO() {
    }

    public RegistroExtremoDTO(int idProgreso, LocalDate fecha, LocalDateTime hora, int nivelControlIra, String observaciones, String metaEmocional) {
        this.idProgreso = idProgreso;
        this.fecha = fecha;
        this.hora = hora;
        this.nivelControlIra = nivelControlIra;
        this.observaciones = observaciones;
        this.metaEmocional = metaEmocional;
    }

    public int getIdProgreso() {
        return idProgreso;
    }

    public void setIdProgreso(int idProgreso) {
        this.idProgreso = idProgreso;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public LocalDateTime getHora() {
        return hora;
    }

    public void setHora(LocalDateTime hora) {
        this.hora = hora;
    }

    public int getNivelControlIra() {
        return nivelControlIra;
    }

    public void setNivelControlIra(int nivelControlIra) {
        this.nivelControlIra = nivelControlIra;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getMetaEmocional() {
        return metaEmocional;
    }

    public void setMetaEmocional(String metaEmocional) {
        this.metaEmocional = metaEmocional;
    }
}
