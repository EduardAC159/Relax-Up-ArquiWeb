package pe.edu.upc.relaxup.Dtos;

import jakarta.persistence.Column;
import pe.edu.upc.relaxup.Entities.MetaEmocional;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class ProgresoDTO {
    private int idProgreso;
    private int nivelControlIra;
    private LocalDate fecha;
    private String observaciones;
    private MetaEmocional metaEmocional;
    private LocalDateTime hora;

    public int getIdProgreso() {
        return idProgreso;
    }

    public void setIdProgreso(int idProgreso) {
        this.idProgreso = idProgreso;
    }

    public int getNivelControlIra() {
        return nivelControlIra;
    }

    public void setNivelControlIra(int nivelControlIra) {
        this.nivelControlIra = nivelControlIra;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public MetaEmocional getMetaEmocional() {
        return metaEmocional;
    }

    public void setMetaEmocional(MetaEmocional metaEmocional) {
        this.metaEmocional = metaEmocional;
    }

    public LocalDateTime getHora() {
        return hora;
    }

    public void setHora(LocalDateTime hora) {
        this.hora = hora;
    }
}
