package pe.edu.upc.relaxup.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.relaxup.Dtos.*;
import pe.edu.upc.relaxup.Entities.Progreso;
import pe.edu.upc.relaxup.Entities.Recordatorio;
import pe.edu.upc.relaxup.ServiceInterfaces.IProgresoService;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/Progreso")
public class ProgresoController {
    @Autowired
    private IProgresoService pS;

    @GetMapping("/Listar")
    public ResponseEntity<List<ProgresoDTO>> Listar(){
        ModelMapper m = new ModelMapper();
        List<ProgresoDTO> ListarProgreso = pS.list().stream()
                .map(x->m.map(x,ProgresoDTO.class)).collect(Collectors.toList());
        return ResponseEntity.ok(ListarProgreso);
    }
    @PostMapping("/nuevo")
    public ResponseEntity<?> registrar(@RequestBody ProgresoDTO dto){
        ModelMapper m = new ModelMapper();
        Progreso p = m.map(dto, Progreso.class);

        Progreso pro = pS.insert(p);
        ProgresoDTO progresoDTO = m.map(pro, ProgresoDTO.class);
        return ResponseEntity.status(HttpStatus.CREATED).body(progresoDTO);
    }

    @PutMapping("/actualiza")
    public ResponseEntity<String> actualizar(@RequestBody ProgresoDTO dto) {

        Optional<Progreso> existente = pS.listId(dto.getIdProgreso());
        if (existente.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Progreso  no encontrado");
        }

        Progreso pro = existente.get();

        pro.setNivelControlIra(dto.getNivelControlIra());
        pro.setFecha(dto.getFecha());
        pro.setObservaciones(dto.getObservaciones());

        pS.update(pro);

        return ResponseEntity.ok("Recodatorio actualizado correctamente");
    }

    @GetMapping("/PromedioControlIra/{idUsuario}")  // Agregar {idUsuario}
    public ResponseEntity<?> promedioControlIra(
            @PathVariable int idUsuario,
            @RequestParam(required = false) String periodo) {

        Double promedio;
        Long total = pS.totalRegistros(idUsuario);

        if (total == 0) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No hay registros de progreso para este usuario");
        }

        if (periodo != null) {
            LocalDate fechaFin = LocalDate.now();
            LocalDate fechaInicio;

            switch(periodo.toLowerCase()) {
                case "1mes":
                    fechaInicio = fechaFin.minusMonths(1);
                    break;
                case "3meses":
                    fechaInicio = fechaFin.minusMonths(3);
                    break;
                case "6meses":
                    fechaInicio = fechaFin.minusMonths(6);
                    break;
                case "1año":
                    fechaInicio = fechaFin.minusYears(1);
                    break;
                default:
                    return ResponseEntity.badRequest()
                            .body("Período no válido: " + periodo);
            }

            promedio = pS.promedioControlIraPorPeriodo(idUsuario, fechaInicio, fechaFin);
            total = pS.totalRegistros(idUsuario); // Idealmente también filtrar por período
        } else {
            promedio = pS.promedioControlIra(idUsuario);
        }

        PromedioControlIraDTO respuesta = new PromedioControlIraDTO(
                idUsuario, promedio, total, periodo != null ? periodo : "general"
        );

        return ResponseEntity.ok(respuesta);
    }

    @GetMapping("/ExtremosControlIra/{idUsuario}")  // Agregar {idUsuario}
    public ResponseEntity<?> extremosControlIra(
            @PathVariable int idUsuario,
            @RequestParam(required = false, defaultValue = "false") boolean incluirEmpates) {

        Long totalRegistros = pS.totalRegistros(idUsuario);

        if (totalRegistros == 0) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No hay registros de progreso para este usuario");
        }

        // Obtener mejores y peores registros
        List<Progreso> mejores = pS.mejoresRegistros(idUsuario);
        List<Progreso> peores = pS.peoresRegistros(idUsuario);

        // Mapear a DTO usando streams correctamente
        List<RegistroExtremoDTO> mejoresDTO = mejores.stream()
                .map(p -> new RegistroExtremoDTO(
                        p.getIdProgreso(),
                        p.getFecha(),
                        p.getHora(),
                        p.getNivelControlIra(),
                        p.getObservaciones(),
                        p.getMetaEmocional().getDescripcion()
                ))
                .collect(Collectors.toList());

        List<RegistroExtremoDTO> peoresDTO = peores.stream()
                .map(p -> new RegistroExtremoDTO(
                        p.getIdProgreso(),
                        p.getFecha(),
                        p.getHora(),
                        p.getNivelControlIra(),
                        p.getObservaciones(),
                        p.getMetaEmocional().getDescripcion()
                ))
                .collect(Collectors.toList());

        // Si no se incluyen empates, tomar solo el primero
        if (!incluirEmpates) {
            if (!mejoresDTO.isEmpty()) {
                mejoresDTO = mejoresDTO.subList(0, 1);
            }
            if (!peoresDTO.isEmpty()) {
                peoresDTO = peoresDTO.subList(0, 1);
            }
        }

        ExtremosControlIraDTO respuesta = new ExtremosControlIraDTO(
                idUsuario,
                mejoresDTO,
                peoresDTO,
                totalRegistros
        );

        return ResponseEntity.ok(respuesta);
    }

}
