package pe.edu.upc.relaxup.Dtos;

import java.util.List;

public class ExtremosControlIraDTO {
    private int idUsuario;
    private List<RegistroExtremoDTO> mejorControl;
    private List<RegistroExtremoDTO> peorControl;
    private Long totalRegistrosAnalizados;

    public ExtremosControlIraDTO() {
    }

    public ExtremosControlIraDTO(int idUsuario, List<RegistroExtremoDTO> mejorControl, List<RegistroExtremoDTO> peorControl, Long totalRegistrosAnalizados) {
        this.idUsuario = idUsuario;
        this.mejorControl = mejorControl;
        this.peorControl = peorControl;
        this.totalRegistrosAnalizados = totalRegistrosAnalizados;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public List<RegistroExtremoDTO> getMejorControl() {
        return mejorControl;
    }

    public void setMejorControl(List<RegistroExtremoDTO> mejorControl) {
        this.mejorControl = mejorControl;
    }

    public List<RegistroExtremoDTO> getPeorControl() {
        return peorControl;
    }

    public void setPeorControl(List<RegistroExtremoDTO> peorControl) {
        this.peorControl = peorControl;
    }

    public Long getTotalRegistrosAnalizados() {
        return totalRegistrosAnalizados;
    }

    public void setTotalRegistrosAnalizados(Long totalRegistrosAnalizados) {
        this.totalRegistrosAnalizados = totalRegistrosAnalizados;
    }
}
