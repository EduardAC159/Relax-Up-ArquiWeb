package pe.edu.upc.relaxup.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.relaxup.Entities.Progreso;

import java.util.List;

@Repository
public interface IProgresoRepository extends JpaRepository<Progreso,Integer> {
    // Query 1: Promedio general de control de ira por usuario
    @Query("SELECT AVG(p.nivelControlIra) FROM Progreso p WHERE p.metaEmocional.usuario.idUsuario = :idUsuario")
    Double promedioControlIraPorUsuario(@Param("idUsuario") int idUsuario);

    // Contar registros para el promedio
    @Query("SELECT COUNT(p) FROM Progreso p WHERE p.metaEmocional.usuario.idUsuario = :idUsuario")
    Long contarRegistrosUsuario(@Param("idUsuario") int idUsuario);

    @Query("SELECT AVG(p.nivelControlIra) FROM Progreso p WHERE p.metaEmocional.usuario.idUsuario = :idUsuario " +
            "AND p.fecha >= :fechaInicio AND p.fecha <= :fechaFin")
    Double promedioControlIraPorUsuarioYPeriodo(
            @Param("idUsuario") int idUsuario,
            @Param("fechaInicio") java.time.LocalDate fechaInicio,
            @Param("fechaFin") java.time.LocalDate fechaFin
    );

    // ===== US-02: Extremos =====

    // Obtener el valor máximo de control de ira para un usuario
    @Query("SELECT MAX(p.nivelControlIra) FROM Progreso p WHERE p.metaEmocional.usuario.idUsuario = :idUsuario")
    Integer maxNivelControlIra(@Param("idUsuario") int idUsuario);

    // Obtener el valor mínimo de control de ira para un usuario
    @Query("SELECT MIN(p.nivelControlIra) FROM Progreso p WHERE p.metaEmocional.usuario.idUsuario = :idUsuario")
    Integer minNivelControlIra(@Param("idUsuario") int idUsuario);

    // Obtener todos los registros con el nivel máximo (maneja empates)
    @Query("SELECT p FROM Progreso p WHERE p.metaEmocional.usuario.idUsuario = :idUsuario " +
            "AND p.nivelControlIra = (SELECT MAX(p2.nivelControlIra) FROM Progreso p2 WHERE p2.metaEmocional.usuario.idUsuario = :idUsuario)")
    List<Progreso> mejoresRegistros(@Param("idUsuario") int idUsuario);

    // Obtener todos los registros con el nivel mínimo (maneja empates)
    @Query("SELECT p FROM Progreso p WHERE p.metaEmocional.usuario.idUsuario = :idUsuario " +
            "AND p.nivelControlIra = (SELECT MIN(p2.nivelControlIra) FROM Progreso p2 WHERE p2.metaEmocional.usuario.idUsuario = :idUsuario)")
    List<Progreso> peoresRegistros(@Param("idUsuario") int idUsuario);
}
