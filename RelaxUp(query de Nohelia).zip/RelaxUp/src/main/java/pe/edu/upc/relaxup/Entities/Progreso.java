package pe.edu.upc.relaxup.Entities;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
@Entity
@Table(name = "Progreso")
public class Progreso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idProgreso;

    @Column(name = "nivel_control_ira",nullable = false)
    private int nivelControlIra;

    @Column(name = "fecha", nullable = false)
    private LocalDate fecha;

    @Column(name = "observaciones",nullable = false,length = 200)
    private String observaciones;

    @ManyToOne
    @JoinColumn(name = "idMetaEmocional")
    private MetaEmocional metaEmocional;

    @Column(name = "hora",nullable = false)
    private LocalDateTime hora;

    public Progreso() {
    }

    public Progreso(int idProgreso, int nivelControlIra, LocalDate fecha, String observaciones, MetaEmocional metaEmocional, LocalDateTime hora) {
        this.idProgreso = idProgreso;
        this.nivelControlIra = nivelControlIra;
        this.fecha = fecha;
        this.observaciones = observaciones;
        this.metaEmocional = metaEmocional;
        this.hora = hora;
    }

    public int getIdProgreso() {
        return idProgreso;
    }

    public void setIdProgreso(int idProgreso) {
        this.idProgreso = idProgreso;
    }

    public int getNivelControlIra() {
        return nivelControlIra;
    }

    public void setNivelControlIra(int nivelControlIra) {
        this.nivelControlIra = nivelControlIra;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public MetaEmocional getMetaEmocional() {
        return metaEmocional;
    }

    public void setMetaEmocional(MetaEmocional metaEmocional) {
        this.metaEmocional = metaEmocional;
    }

    public LocalDateTime getHora() {
        return hora;
    }

    public void setHora(LocalDateTime hora) {
        this.hora = hora;
    }
}
