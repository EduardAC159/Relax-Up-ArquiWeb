package pe.edu.upc.relaxup.Dtos;

public class PromedioControlIraDTO {
    private int idUsuario;
    private Double promedioControlIra;
    private Long totalRegistros;
    private String periodo;

    public PromedioControlIraDTO() {
    }

    public PromedioControlIraDTO(int idUsuario, Double promedioControlIra, Long totalRegistros, String periodo) {
        this.idUsuario = idUsuario;
        this.promedioControlIra = promedioControlIra;
        this.totalRegistros = totalRegistros;
        this.periodo = periodo;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Double getPromedioControlIra() {
        return promedioControlIra;
    }

    public void setPromedioControlIra(Double promedioControlIra) {
        this.promedioControlIra = promedioControlIra;
    }

    public Long getTotalRegistros() {
        return totalRegistros;
    }

    public void setTotalRegistros(Long totalRegistros) {
        this.totalRegistros = totalRegistros;
    }

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }
}
