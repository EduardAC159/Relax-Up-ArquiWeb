package pe.edu.upc.relaxup.ServiceInterfaces;

import pe.edu.upc.relaxup.Entities.Progreso;
import pe.edu.upc.relaxup.Entities.Recordatorio;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface IProgresoService {
    public List<Progreso> list();
    public Progreso insert(Progreso progreso);
    public void update(Progreso progreso);
    public void delete(int id);
    public Optional<Progreso> listId(int id);

    // Nuevos métodos para US-01
    public Double promedioControlIra(int idUsuario);
    public Double promedioControlIraPorPeriodo(int idUsuario, LocalDate inicio, LocalDate fin);
    public Long totalRegistros(int idUsuario);

    // US-02
    public List<Progreso> mejoresRegistros(int idUsuario);
    public List<Progreso> peoresRegistros(int idUsuario);
}
